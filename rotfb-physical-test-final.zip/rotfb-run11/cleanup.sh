#!/bin/sh
set -eu
BASE=${ROTFB_BASE:-/var/tmp/rotfb-run11}
STATE="$BASE/run.state"
RESTORE_FMRI=${1:-}
. "$BASE/common.sh"
[ "$(id -u)" -eq 0 ] || { echo "run from root" >&2; exit 1; }

if [ ! -f "$STATE" ]; then
    if [ -n "$RESTORE_FMRI" ] && [ -f "$BASE/run.state.completed" ]; then
        RECORDED_FMRI=$(sed -n 's/^DM_FMRI=//p' "$BASE/run.state.completed" | sed -n '1p')
        [ "$RESTORE_FMRI" = "$RECORDED_FMRI" ] || { echo "refusing to enable unrecorded FMRI; expected $RECORDED_FMRI" >&2; exit 2; }
        command -v svcadm >/dev/null 2>&1 || { echo "svcadm unavailable; restore $RESTORE_FMRI manually" >&2; exit 2; }
        echo "Restoring exact preflight display manager service temporarily: $RESTORE_FMRI"
        svcadm enable -t -s "$RESTORE_FMRI"
        exit 0
    fi
    echo "No active Run #11 state file: $STATE"
    exit 0
fi

read_state() {
    sed -n "s/^$1=//p" "$STATE" | sed -n '1p'
}
XORG_PID=$(read_state XORG_PID)
DTRACE_PID=$(read_state DTRACE_PID)
DISPLAY_NUM=$(read_state DISPLAY)
VT=$(read_state VT)
DM_FMRI=$(read_state DM_FMRI)
DLOG="$BASE/dtrace.$DISPLAY_NUM.log"

case "$XORG_PID" in ''|0) XORG_PID=;; *[!0-9]*) echo "Invalid XORG_PID in state; refusing to signal" >&2; exit 2;; esac
case "$DTRACE_PID" in ''|0) DTRACE_PID=;; *[!0-9]*) echo "Invalid DTRACE_PID in state; refusing to signal" >&2; exit 2;; esac

if [ -n "$XORG_PID" ]; then
    CURRENT_XORGS=$(pgrep -x Xorg 2>/dev/null || true)
    if printf '%s\n' "$CURRENT_XORGS" | awk -v p="$XORG_PID" '$1 == p { found=1 } END { exit !found }'; then
        echo "Sending SIGTERM only to recorded Run #11 Xorg PID $XORG_PID"
        kill -TERM "$XORG_PID"
        i=0
        while [ "$i" -lt 45 ] && kill -0 "$XORG_PID" 2>/dev/null; do
            sleep 1
            i=$((i + 1))
        done
        if kill -0 "$XORG_PID" 2>/dev/null && pgrep -x Xorg 2>/dev/null | grep -x "$XORG_PID" >/dev/null; then
            echo "BLOCKED: Xorg PID $XORG_PID is still alive after 45s; no SIGKILL sent." >&2
            echo "Use the independent recovery shell. If the VT cannot be recovered, reboot restores the untouched system configuration." >&2
            exit 2
        fi
    else
        echo "Recorded Xorg PID $XORG_PID is no longer an Xorg process; no signal sent."
    fi
fi

if [ -n "$DTRACE_PID" ] && kill -0 "$DTRACE_PID" 2>/dev/null; then
    i=0
    while [ "$i" -lt 20 ] && kill -0 "$DTRACE_PID" 2>/dev/null; do
        sleep 1
        i=$((i + 1))
    done
    if kill -0 "$DTRACE_PID" 2>/dev/null; then
        echo "BLOCKED: DTrace process $DTRACE_PID remains alive; no SIGKILL sent." >&2
        exit 2
    fi
fi

# Do not infer successful VT restoration from Xorg exit alone.
if [ -f "$DLOG" ] && grep -q 'KDSETMODE_GRAPHICS_SUCCESS' "$DLOG"; then
    if ! grep -q 'KDSETMODE_TEXT_SUCCESS' "$DLOG"; then
        if [ "${ROTFB_KDTEXT_CONFIRMED:-NO}" != YES ]; then
            echo "BLOCKED: DTrace saw KD_GRAPHICS but did not record KD_TEXT success." >&2
            echo "Manually verify a usable text console from the recovery shell; then rerun with ROTFB_KDTEXT_CONFIRMED=YES." >&2
            exit 2
        fi
        echo "WARNING: KD_TEXT restoration accepted by explicit operator confirmation, not DTrace evidence."
    fi
else
    if [ "${ROTFB_KDTEXT_CONFIRMED:-NO}" != YES ]; then
        echo "BLOCKED: no DTrace proof of the graphics/text transition." >&2
        echo "Manually verify a usable text console from the recovery shell; then rerun with ROTFB_KDTEXT_CONFIRMED=YES." >&2
        exit 2
    fi
    echo "WARNING: VT state accepted by explicit operator confirmation, not DTrace evidence."
fi

# Ensure the Xorg process has exited and neither framebuffer nor test VT has
# another user-space process owner before any service restoration.
[ -c /dev/fb0 ] || { echo "BLOCKED: /dev/fb0 missing after test" >&2; exit 2; }
[ -c "/dev/vt/$VT" ] || { echo "BLOCKED: /dev/vt/$VT missing after test" >&2; exit 2; }
rotfb_fuser_check /dev/fb0 framebuffer || { echo "BLOCKED: cannot inspect /dev/fb0 after test" >&2; exit 2; }
[ "$ROTFB_FUSER_RESULT" = FREE ] || { echo "BLOCKED: /dev/fb0 still has an owner" >&2; exit 2; }
rotfb_fuser_check "/dev/vt/$VT" "VT /dev/vt/$VT" || { echo "BLOCKED: cannot inspect test VT after test" >&2; exit 2; }
[ "$ROTFB_FUSER_RESULT" = FREE ] || { echo "BLOCKED: test VT still has an owner" >&2; exit 2; }

mv "$STATE" "$STATE.completed"
echo "Run #11 Xorg exited; framebuffer and test VT have no fuser owners."
echo "Console state: verified according to the evidence/explicit operator confirmation above."
if [ -n "$RESTORE_FMRI" ]; then
    [ "$RESTORE_FMRI" = "$DM_FMRI" ] || { echo "BLOCKED: FMRI does not match preflight snapshot ($DM_FMRI)" >&2; exit 2; }
    command -v svcadm >/dev/null 2>&1 || { echo "svcadm unavailable; restore $RESTORE_FMRI manually" >&2; exit 2; }
    echo "Restoring exact preflight display manager: $RESTORE_FMRI"
    svcadm enable -t -s "$RESTORE_FMRI"
fi
