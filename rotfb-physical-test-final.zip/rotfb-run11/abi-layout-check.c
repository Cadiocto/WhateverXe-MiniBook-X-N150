/*
 * Independent amd64 ABI layout assertions for illumos sys/fbio.h.
 * The declarations below are copied verbatim in field order and type width
 * from illumos-gate sys/fbio.h at commit
 * 098e95820891f8a83fae679daece7fcf58b7b3a4.
 */
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

struct fbtype {
    int fb_type;
    int fb_height;
    int fb_width;
    int fb_depth;
    int fb_cmsize;
    int fb_size;
};

#define FB_ATTR_NDEVSPECIFIC 8
#define FB_ATTR_NEMUTYPES 4
struct fbsattr {
    int flags;
    int emu_type;
    int dev_specific[FB_ATTR_NDEVSPECIFIC];
};
struct fbgattr {
    int real_type;
    int owner;
    struct fbtype fbtype;
    struct fbsattr sattr;
    int emu_types[FB_ATTR_NEMUTYPES];
};
struct gfxfb_info {
    uint16_t terminal_origin_x;
    uint16_t terminal_origin_y;
    uint32_t pitch;
    uint16_t font_width;
    uint16_t font_height;
    uint8_t red_mask_size;
    uint8_t red_field_position;
    uint8_t green_mask_size;
    uint8_t green_field_position;
    uint8_t blue_mask_size;
    uint8_t blue_field_position;
};

#define ASSERT_SIZE(type, n) _Static_assert(sizeof(type) == (n), #type " size")
#define ASSERT_OFF(type, field, n) \
    _Static_assert(offsetof(type, field) == (n), #type "." #field " offset")

ASSERT_SIZE(int, 4);
ASSERT_SIZE(void *, 8);
ASSERT_SIZE(struct fbtype, 24);
ASSERT_OFF(struct fbtype, fb_type, 0);
ASSERT_OFF(struct fbtype, fb_height, 4);
ASSERT_OFF(struct fbtype, fb_width, 8);
ASSERT_OFF(struct fbtype, fb_depth, 12);
ASSERT_OFF(struct fbtype, fb_cmsize, 16);
ASSERT_OFF(struct fbtype, fb_size, 20);
ASSERT_SIZE(struct fbsattr, 40);
ASSERT_OFF(struct fbsattr, flags, 0);
ASSERT_OFF(struct fbsattr, emu_type, 4);
ASSERT_OFF(struct fbsattr, dev_specific, 8);
ASSERT_SIZE(struct fbgattr, 88);
ASSERT_OFF(struct fbgattr, real_type, 0);
ASSERT_OFF(struct fbgattr, owner, 4);
ASSERT_OFF(struct fbgattr, fbtype, 8);
ASSERT_OFF(struct fbgattr, sattr, 32);
ASSERT_OFF(struct fbgattr, emu_types, 72);
ASSERT_SIZE(struct gfxfb_info, 20);
ASSERT_OFF(struct gfxfb_info, terminal_origin_x, 0);
ASSERT_OFF(struct gfxfb_info, terminal_origin_y, 2);
ASSERT_OFF(struct gfxfb_info, pitch, 4);
ASSERT_OFF(struct gfxfb_info, font_width, 8);
ASSERT_OFF(struct gfxfb_info, font_height, 10);
ASSERT_OFF(struct gfxfb_info, red_mask_size, 12);
ASSERT_OFF(struct gfxfb_info, red_field_position, 13);
ASSERT_OFF(struct gfxfb_info, green_mask_size, 14);
ASSERT_OFF(struct gfxfb_info, green_field_position, 15);
ASSERT_OFF(struct gfxfb_info, blue_mask_size, 16);
ASSERT_OFF(struct gfxfb_info, blue_field_position, 17);

int main(void)
{
    printf("ABI_LAYOUT=PASS fbgattr=%zu fbtype=%zu fbsattr=%zu gfxfb_info=%zu\n",
        sizeof (struct fbgattr), sizeof (struct fbtype),
        sizeof (struct fbsattr), sizeof (struct gfxfb_info));
    printf("OFFSETS=PASS real_type:0 owner:4 fbtype:8 sattr:32 dev_specific:40 emu_types:72\n");
    printf("GFXFB_INFO=PASS overlay_offset:40 fields:0..17 tail_padding:2\n");
    return (0);
}
