#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
. "$ROOT/common.sh"
TMP=${TMPDIR:-/tmp}/rotfb-harness-tests.$$
mkdir -p "$TMP"
trap 'rm -rf "$TMP"' EXIT HUP INT TERM

# DTrace list output with MODULE populated and blank.
cat > "$TMP/dtrace.blank" <<'EOT'
 ID PROVIDER MODULE FUNCTION NAME
 101 syscall        ioctl entry
 102 syscall        ioctl return
 103 syscall        mmap entry
 104 pid777 libfb.so fbScreenInit entry
 105 pid777 libshadow.so shadowAdd return
 106 pid777        shadowUpdateRotate32_270 entry
EOT
rotfb_dtrace_has_probe "$TMP/dtrace.blank" syscall "" ioctl entry
rotfb_dtrace_has_probe "$TMP/dtrace.blank" pid777 libfb.so fbScreenInit entry
rotfb_dtrace_has_probe "$TMP/dtrace.blank" pid777 libshadow.so shadowAdd return
rotfb_dtrace_has_probe "$TMP/dtrace.blank" pid777 libshadow.so shadowUpdateRotate32_270 entry
if rotfb_dtrace_has_probe "$TMP/dtrace.blank" pid777 libfb.so shadowAdd entry; then
    echo "DTrace parser false positive" >&2; exit 1
fi

# Solaris nm -P: symbol type value size; local text symbols use lower-case t.
cat > "$TMP/nm.P" <<'EOT'
IlFbProbe t 30d2 225
IlFbOpenDev t 2c34 49e
IlFbPreInit t 3398 5de
IlFbScreenInit t 3b00 1a0
IlFbCreateScreenResources t 3c5d 2cb
IlFbRotateUpdate t 41a0 50
IlFbWindowLinear t 4200 1d5
IlFbEmpty t 4300 0
NOT_TEXT U
EOT
for symbol in IlFbProbe IlFbOpenDev IlFbPreInit IlFbScreenInit IlFbCreateScreenResources IlFbRotateUpdate IlFbWindowLinear; do
    rotfb_nm_has_text_symbol "$TMP/nm.P" "$symbol"
done
if rotfb_nm_has_text_symbol "$TMP/nm.P" IlFbEmpty; then
    echo "nm parser accepted zero-sized symbol" >&2; exit 1
fi

# Fuser result-state tests use the production helper against /dev/null, which
# is a character device in both the Linux test container and OpenIndiana VM.
FAKE="$TMP/fuser"
cat > "$FAKE" <<'EOT'
#!/bin/sh
case ${FUSER_FIXTURE:-free} in
 free) echo "$2:" >&2; exit 0 ;;
 free-clean) exit 0 ;;
 process) echo '1234o'; exit 0 ;;
 kernel) echo '[/dev/console]' >&2; exit 0 ;;
 denied) echo "$2: Permission denied" >&2; exit 2 ;;
 broken) echo "$2: cannot stat" >&2; exit 3 ;;
 *) exit 9 ;;
esac
EOT
chmod +x "$FAKE"
rotfb_find_fuser() { ROTFB_FUSER="$FAKE"; }
FUSER_FIXTURE=free rotfb_fuser_check /dev/null char-device; [ "$ROTFB_FUSER_RESULT" = FREE ]
FUSER_FIXTURE=free-clean rotfb_fuser_check /dev/null char-device; [ "$ROTFB_FUSER_RESULT" = FREE ]
FUSER_FIXTURE=process rotfb_fuser_check /dev/null char-device; [ "$ROTFB_FUSER_RESULT" = BUSY ]
FUSER_FIXTURE=kernel rotfb_fuser_check /dev/null char-device; [ "$ROTFB_FUSER_RESULT" = BUSY ]
if FUSER_FIXTURE=denied rotfb_fuser_check /dev/null char-device; then exit 1; fi
[ "$ROTFB_FUSER_RESULT" = ERROR ]
if FUSER_FIXTURE=broken rotfb_fuser_check /dev/null char-device; then exit 1; fi
[ "$ROTFB_FUSER_RESULT" = ERROR ]

echo 'PARSER_TESTS=PASS dtrace_blank_module,nm_posix,fuser_free_busy_kernel_error'
