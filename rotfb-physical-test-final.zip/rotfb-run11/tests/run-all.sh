#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname "$0")/.." && pwd)
. "$ROOT/common.sh"
for script in common.sh preflight.sh launch.sh cleanup.sh tests/test-parsers.sh; do
    /bin/sh -n "$ROOT/$script"
done
echo 'SHELL_SYNTAX=PASS'
"$ROOT/tests/test-parsers.sh"
perl -c "$ROOT/rotfb-fbgattr-detail-probe.pl"
perl "$ROOT/rotfb-fbgattr-detail-probe.pl" --abi-only
CC=
for candidate in /usr/gcc/14/bin/gcc /usr/gcc/13/bin/gcc /usr/bin/gcc /usr/bin/cc; do
    if [ -x "$candidate" ]; then CC=$candidate; break; fi
done
if [ -n "$CC" ]; then
    "$CC" -std=c11 -Wall -Wextra -Werror -o "${TMPDIR:-/tmp}/rotfb-abi-check.$$" "$ROOT/abi-layout-check.c"
    "${TMPDIR:-/tmp}/rotfb-abi-check.$$"
    rm -f "${TMPDIR:-/tmp}/rotfb-abi-check.$$"
else
    echo 'ABI_C_COMPILE=SKIP_NO_COMPILER'
fi
EXPECTED=db845048abf8ba0245ff45a023c0ca9b28f5488b442274d7955e52a560e25720
if command -v digest >/dev/null 2>&1; then
    ACTUAL=$(digest -a sha256 "$ROOT/modules/drivers/amd64/illumosfb_drv.so" | awk '{print $1}')
else
    ACTUAL=$(sha256sum "$ROOT/modules/drivers/amd64/illumosfb_drv.so" | awk '{print $1}')
fi
[ "$ACTUAL" = "$EXPECTED" ]
echo "DDX_SHA256=PASS $ACTUAL"
if [ -x /usr/bin/nm ]; then
    /usr/bin/nm -P "$ROOT/modules/drivers/amd64/illumosfb_drv.so" > "${TMPDIR:-/tmp}/rotfb-nm.$$.txt"
    for symbol in IlFbProbe IlFbOpenDev IlFbPreInit IlFbScreenInit IlFbCreateScreenResources IlFbRotateUpdate IlFbWindowLinear; do
        rotfb_nm_has_text_symbol "${TMPDIR:-/tmp}/rotfb-nm.$$.txt" "$symbol"
    done
    rm -f "${TMPDIR:-/tmp}/rotfb-nm.$$.txt"
    echo 'SOLARIS_NM_P=PASS'
fi
if [ -x /usr/sbin/fuser ] && [ -c /dev/zero ]; then
    rotfb_fuser_check /dev/zero 'fuser real-device probe' || { echo 'FUSER_REAL=ERROR'; exit 1; }
    echo "FUSER_REAL=PASS classification=$ROTFB_FUSER_RESULT"
fi
if command -v dtrace >/dev/null 2>&1; then
    DTRACE=$(command -v dtrace)
    "$DTRACE" -l -n 'syscall::ioctl:entry' > "${TMPDIR:-/tmp}/rotfb-dtrace.$$.txt" 2>&1
    rotfb_dtrace_has_probe "${TMPDIR:-/tmp}/rotfb-dtrace.$$.txt" syscall '' ioctl entry
    "$DTRACE" -e -Z -c /usr/bin/true -s "$ROOT/dtrace.d" > "${TMPDIR:-/tmp}/rotfb-dtrace-compile.$$.txt" 2>&1
    rm -f "${TMPDIR:-/tmp}/rotfb-dtrace.$$.txt" "${TMPDIR:-/tmp}/rotfb-dtrace-compile.$$.txt"
    echo 'DTRACE_SYSCALL_AND_COMPILE=PASS'
else
    echo 'DTRACE_SYSCALL_AND_COMPILE=SKIP_NOT_OPENINDIANA'
fi
