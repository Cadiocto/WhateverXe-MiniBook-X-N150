#!/bin/sh
set -eu
BASE=${ROTFB_BASE:-/var/tmp/rotfb-run11}
MODULES="$BASE/modules"
DDX="$MODULES/drivers/amd64/illumosfb_drv.so"
CONF="$BASE/xorg.conf"
DTRACE_SCRIPT="$BASE/dtrace.d"
EXPECTED_SHA=db845048abf8ba0245ff45a023c0ca9b28f5488b442274d7955e52a560e25720
DISPLAY_NUM=${ROTFB_DISPLAY:-1}
VT=${ROTFB_VT:-8}
VTDEV="/dev/vt/$VT"
LOG="$BASE/Xorg.$DISPLAY_NUM.log"
DLOG="$BASE/dtrace.$DISPLAY_NUM.log"
STATE="$BASE/run.state"
BASELINE="$BASE/baseline.state"

. "$BASE/common.sh"
fail() { echo "BLOCKED: $*" >&2; exit 1; }
[ "$(id -u)" -eq 0 ] || fail "run from root"
[ -x /usr/bin/Xorg ] || fail "/usr/bin/Xorg missing"
[ -f "$BASELINE" ] || fail "no successful preflight baseline; do not launch"
[ -f "$DDX" ] && [ -f "$CONF" ] && [ -f "$DTRACE_SCRIPT" ] || fail "kit incomplete"
[ -c /dev/fb0 ] || fail "/dev/fb0 is not a character device"
[ -c "$VTDEV" ] || fail "selected VT no longer exists: $VTDEV"
[ ! -e "$STATE" ] || fail "run.state already exists; inspect previous run before continuing"

# Load the trusted preflight snapshot without sourcing arbitrary shell text.
STOCK_PID=$(sed -n 's/^STOCK_XORG_PID=//p' "$BASELINE" | sed -n '1p')
BASE_VT=$(sed -n 's/^SELECTED_VT=//p' "$BASELINE" | sed -n '1p')
STOCK_VT=$(sed -n 's/^STOCK_XORG_VT=//p' "$BASELINE" | sed -n '1p')
BASE_TTY=$(sed -n 's/^OPERATOR_TTY=//p' "$BASELINE" | sed -n '1p')
DM_FMRI=$(sed -n 's/^DM_FMRI=//p' "$BASELINE" | sed -n '1p')
[ "$BASE_VT" = "$VT" ] || fail "ROTFB_VT changed since preflight (baseline=$BASE_VT current=$VT)"
[ -n "$STOCK_VT" ] && [ "$STOCK_VT" != "$VT" ] || fail "test VT is missing or equals stock Xorg VT"
[ -n "$STOCK_PID" ] && [ -n "$DM_FMRI" ] || fail "baseline snapshot is incomplete"
CURRENT_TTY=$(rotfb_current_tty) || fail "launch shell has no controlling terminal"
[ "$CURRENT_TTY" = "$BASE_TTY" ] || fail "launch must run from the same independent root TTY recorded at preflight"

ACTUAL_SHA=$(digest -a sha256 "$DDX" | awk '{print $1}')
[ "$ACTUAL_SHA" = "$EXPECTED_SHA" ] || fail "Run #11 DDX SHA256 mismatch: $ACTUAL_SHA"
[ -f /usr/lib/xorg/modules/amd64/libfb.so ] || fail "system libfb.so missing"
[ -f /usr/lib/xorg/modules/amd64/libshadow.so ] || fail "system libshadow.so missing"

XORG_LIST=$(pgrep -x Xorg 2>/dev/null || true)
[ -z "$XORG_LIST" ] || fail "Xorg still running; do not start a second server: $XORG_LIST"
DM_STATE=$(svcs -H -o state "$DM_FMRI" 2>/dev/null | sed -n '1p')
[ "$DM_STATE" = disabled ] || fail "display manager $DM_FMRI must be temporarily disabled; state=${DM_STATE:-unknown}"

rotfb_fuser_check /dev/fb0 framebuffer || fail "cannot establish /dev/fb0 ownership state"
[ "$ROTFB_FUSER_RESULT" = FREE ] || fail "/dev/fb0 is still occupied"
rotfb_fuser_check "$VTDEV" "VT $VTDEV" || fail "cannot establish selected VT ownership state"
[ "$ROTFB_FUSER_RESULT" = FREE ] || fail "$VTDEV is still occupied"
[ ! -e "/tmp/.X${DISPLAY_NUM}-lock" ] || fail "X display :$DISPLAY_NUM lock exists"
[ ! -e "/tmp/.X11-unix/X${DISPLAY_NUM}" ] || fail "X display socket :$DISPLAY_NUM exists"

# Keep the test display and module search paths private. No system driver path.
MODULEPATH="$MODULES,/usr/lib/xorg/modules/amd64"
XORG_CMD="/usr/bin/Xorg :$DISPLAY_NUM vt$VT -config $CONF -modulepath $MODULEPATH -logfile $LOG -logverbose 7 -nolisten tcp"
DTRACE=$(command -v dtrace) || fail "DTrace missing; this acceptance kit requires instrumentation. This is not a DDX failure."

printf 'BASE=%s\nDISPLAY=%s\nVT=%s\nDM_FMRI=%s\nDTRACE_PID=0\nXORG_PID=0\nDDX_SHA256=%s\nXORG_LOG=%s\nDTRACE_LOG=%s\n' \
    "$BASE" "$DISPLAY_NUM" "$VT" "$DM_FMRI" "$ACTUAL_SHA" "$LOG" "$DLOG" > "$STATE.tmp"
chmod 600 "$STATE.tmp"
mv "$STATE.tmp" "$STATE"

printf 'Run #11 SHA256 verified: %s\n' "$ACTUAL_SHA"
printf 'Starting private Xorg :%s on VT%s; LightDM remains disabled by operator action.\n' "$DISPLAY_NUM" "$VT"
printf 'Type START-RUN11 to continue: '
read ANSWER
[ "$ANSWER" = START-RUN11 ] || { rm -f "$STATE"; fail "operator declined launch"; }

# dtrace -c owns the child Xorg lifetime; the state is persisted before launch.
if "$DTRACE" -Z -q -s "$DTRACE_SCRIPT" -o "$DLOG" -c "$XORG_CMD" >"$BASE/dtrace.stdout" 2>&1 & then
    DTRACE_PID=$!
else
    fail "could not start DTrace wrapper"
fi
printf 'DTRACE_PID=%s\n' "$DTRACE_PID" >> "$STATE"

# Discover and persist the child PID even if the BEGIN marker is delayed.
i=0
XORG_PID=
while [ "$i" -lt 45 ]; do
    XORG_PID=$(sed -n 's/.*ROTFB_DTRACE_BEGIN target_pid=\([0-9][0-9]*\).*/\1/p' "$DLOG" 2>/dev/null | sed -n '1p')
    if [ -n "$XORG_PID" ]; then break; fi
    if ! kill -0 "$DTRACE_PID" 2>/dev/null; then break; fi
    sleep 1
    i=$((i + 1))
done
if [ -z "$XORG_PID" ]; then
    CANDIDATES=$(pgrep -x Xorg 2>/dev/null || true)
    COUNT=$(printf '%s\n' "$CANDIDATES" | awk 'NF { n++ } END { print n+0 }')
    if [ "$COUNT" -eq 1 ]; then
        XORG_PID=$(printf '%s\n' "$CANDIDATES" | sed -n '1p')
        printf 'XORG_PID=%s\n' "$XORG_PID" >> "$STATE"
        echo "DTrace BEGIN marker missing; exact sole Xorg PID $XORG_PID saved for cleanup." >&2
    fi
    fail "DTrace did not publish target PID; preserve logs and run cleanup.sh before restoring LightDM"
fi
printf 'XORG_PID=%s\n' "$XORG_PID" >> "$STATE"

# Wait for Xorg to identify the private DDX and both helper DSOs.
i=0
while [ "$i" -lt 45 ]; do
    if grep -F "$DDX" "$LOG" >/dev/null 2>&1 && \
       grep -F '/usr/lib/xorg/modules/amd64/libfb.so' "$LOG" >/dev/null 2>&1 && \
       grep -F '/usr/lib/xorg/modules/amd64/libshadow.so' "$LOG" >/dev/null 2>&1; then
        break
    fi
    if ! kill -0 "$XORG_PID" 2>/dev/null; then break; fi
    sleep 1
    i=$((i + 1))
done
if ! grep -F "$DDX" "$LOG" >/dev/null 2>&1; then
    fail "Xorg log does not prove the private Run #11 DDX was loaded; cleanup is required"
fi
if grep -F '/usr/lib/xorg/modules/drivers/amd64/illumosfb_drv.so' "$LOG" >/dev/null 2>&1; then
    fail "Xorg log references system illumosfb DDX; cleanup is required"
fi
for helper in libfb.so libshadow.so; do
    grep -F "/usr/lib/xorg/modules/amd64/$helper" "$LOG" >/dev/null 2>&1 || fail "Xorg log does not prove expected helper path for $helper"
done
POST_SHA=$(digest -a sha256 "$DDX" | awk '{print $1}')
[ "$POST_SHA" = "$EXPECTED_SHA" ] || fail "DDX SHA changed during load: $POST_SHA"

printf 'RUN11_MODULE_PATH_CONFIRMED=%s\nRUN11_MODULE_SHA256=%s\n' "$DDX" "$POST_SHA"
echo "Xorg PID=$XORG_PID DTrace PID=$DTRACE_PID"
echo "Logs: $LOG ; $DLOG"
echo "Do not restore LightDM until cleanup.sh confirms Xorg exit and console recovery."
