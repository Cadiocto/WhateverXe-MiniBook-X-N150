#!/bin/sh
# Shared Solaris/illumos-safe helpers for ROTFB Run #11.

rotfb_fail() { echo "BLOCKED: $*" >&2; return 1; }
rotfb_pass() { echo "PASS: $*"; }

rotfb_find_fuser() {
    if [ -x /usr/sbin/fuser ]; then ROTFB_FUSER=/usr/sbin/fuser
    elif [ -x /usr/bin/fuser ]; then ROTFB_FUSER=/usr/bin/fuser
    else return 1
    fi
}

# Result is exported in ROTFB_FUSER_RESULT: FREE, BUSY, or ERROR.
# illumos fuser prints process IDs to stdout and the pathname header plus
# kernel-consumer records to stderr. Exit status 0 means the inspection ran;
# a bare pathname header with no PID/kernel record means no current owner.
rotfb_fuser_check() {
    _rf_path=$1
    _rf_label=$2
    _rf_tmp=${TMPDIR:-/tmp}/rotfb-fuser.$$.out
    _rf_err=${TMPDIR:-/tmp}/rotfb-fuser.$$.err
    ROTFB_FUSER_RESULT=ERROR
    [ -c "$_rf_path" ] || { echo "$_rf_label: not a character device: $_rf_path" >&2; return 1; }
    rotfb_find_fuser || { echo "$_rf_label: fuser executable not found" >&2; return 1; }
    if LC_ALL=C "$ROTFB_FUSER" -f "$_rf_path" >"$_rf_tmp" 2>"$_rf_err"; then
        _rf_rc=0
    else
        _rf_rc=$?
    fi
    _rf_out=$(cat "$_rf_tmp")
    _rf_stderr=$(cat "$_rf_err")
    rm -f "$_rf_tmp" "$_rf_err"

    # illumos/POSIX fuser writes the queried pathname followed by a colon to
    # stderr on successful inspection, whether or not a process is using it.
    # Strip only that exact report header; retain kernel-consumer and errors.
    _rf_diag=$(printf '%s\n' "$_rf_stderr" | awk -v path="$_rf_path" '{ line=$0; sub(/^[[:space:]]+/, "", line); sub(/[[:space:]]+$/, "", line); if (line != path ":" && line != "") print line }')

    if [ "$_rf_rc" -ne 0 ]; then
        ROTFB_FUSER_RESULT=ERROR
        echo "$_rf_label: fuser failed with status $_rf_rc${_rf_diag:+: $_rf_diag}" >&2
        return 1
    fi
    if [ -n "$_rf_out" ]; then
        ROTFB_FUSER_RESULT=BUSY
        echo "$_rf_label: process owner(s): $_rf_out" >&2
        return 0
    fi
    case "$_rf_stderr" in
        *'['*']'*)
            ROTFB_FUSER_RESULT=BUSY
            echo "$_rf_label: kernel consumer reported by fuser: $_rf_stderr" >&2
            return 0
            ;;
    esac
    if [ -n "$_rf_diag" ]; then
        ROTFB_FUSER_RESULT=ERROR
        echo "$_rf_label: fuser diagnostic: $_rf_diag (status $_rf_rc)" >&2
        return 1
    fi
    ROTFB_FUSER_RESULT=FREE
    return 0
}

# Parse `dtrace -l` rows without assuming MODULE is non-empty. FUNCTION/NAME
# are always the last two fields. For module-scoped -n queries, an empty MODULE
# display column is accepted because DTrace already applied that module filter.
rotfb_dtrace_has_probe() {
    _rf_file=$1 _rf_provider=$2 _rf_module=$3 _rf_function=$4 _rf_name=$5
    awk -v p="$_rf_provider" -v m="$_rf_module" -v f="$_rf_function" -v n="$_rf_name" '
        NF >= 4 && $2 == p {
            fn=$(NF-1); nm=$NF; mod=(NF >= 5 ? $3 : "");
            if (fn == f && nm == n && (m == "" || mod == "" || mod == m || mod ~ ("/" m "$"))) found=1;
        }
        END { exit !found }
    ' "$_rf_file"
}

# POSIX nm -P row: NAME TYPE VALUE SIZE. Local text functions are type t.
rotfb_nm_has_text_symbol() {
    _rf_file=$1 _rf_symbol=$2
    awk -v s="$_rf_symbol" '
        $1 == s && ($2 == "t" || $2 == "T") && NF >= 4 && $4 ~ /^[0-9a-fA-F]+$/ {
            if ($4 !~ /^0+$/) found=1;
        }
        END { exit !found }
    ' "$_rf_file"
}

rotfb_current_tty() {
    _rf_tty=$(tty 2>/dev/null || true)
    [ -n "$_rf_tty" ] && [ "$_rf_tty" != "not a tty" ] || return 1
    printf '%s\n' "$_rf_tty"
}
