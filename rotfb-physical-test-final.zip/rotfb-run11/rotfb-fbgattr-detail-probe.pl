#!/usr/bin/perl
use strict;
use warnings;
use Fcntl qw(O_RDONLY);

# illumos-gate sys/fbio.h (amd64): FIOC=('F'<<8), FBIOGATTR=(FIOC|6).
# Exactly one FBIOGATTR is issued in device mode. No other ioctl or writes.
my $arg = shift;
my $abi_only = defined($arg) && $arg eq '--abi-only';
my $path = (defined($arg) && !$abi_only) ? $arg : '/dev/fb0';
my $cmd  = 0x4606;
my $size = 88;

my %OFF = (
    real_type => 0, owner => 4, fbtype => 8,
    fb_type => 8, fb_height => 12, fb_width => 16,
    fb_depth => 20, fb_cmsize => 24, fb_size => 28,
    sattr => 32, flags => 32, emu_type => 36,
    dev_specific => 40, emu_types => 72,
    terminal_origin_x => 40, terminal_origin_y => 42,
    pitch => 44, font_width => 48, font_height => 50,
    red_mask_size => 52, red_field_position => 53,
    green_mask_size => 54, green_field_position => 55,
    blue_mask_size => 56, blue_field_position => 57,
);

sub s32 { return unpack('l<', substr($_[0], $_[1], 4)); }
sub u32 { return unpack('L<', substr($_[0], $_[1], 4)); }
sub u16 { return unpack('S<', substr($_[0], $_[1], 2)); }
sub u8  { return unpack('C',  substr($_[0], $_[1], 1)); }
sub put { substr($_[0], $_[1], length($_[2])) = $_[2]; }
sub assert_eq {
    my ($name, $got, $want) = @_;
    die "ABI self-test failed: $name got=$got expected=$want\n"
        if $got != $want;
}

if ($abi_only) {
    # Synthetic buffer tests both byte offsets and signed/unsigned decoding.
    my $b = "\0" x $size;
    put($b, $OFF{real_type}, pack('l<', -7));
    put($b, $OFF{owner}, pack('l<', 1234));
    put($b, $OFF{fb_type}, pack('l<', 9));
    put($b, $OFF{fb_height}, pack('l<', 1920));
    put($b, $OFF{fb_width}, pack('l<', 1200));
    put($b, $OFF{fb_depth}, pack('l<', 32));
    put($b, $OFF{fb_cmsize}, pack('l<', -1));
    put($b, $OFF{fb_size}, pack('l<', 9216000));
    put($b, $OFF{flags}, pack('l<', -2));
    put($b, $OFF{emu_type}, pack('l<', -1));
    put($b, $OFF{terminal_origin_x}, pack('S<', 65535));
    put($b, $OFF{terminal_origin_y}, pack('S<', 2));
    put($b, $OFF{pitch}, pack('L<', 4800));
    put($b, $OFF{font_width}, pack('S<', 8));
    put($b, $OFF{font_height}, pack('S<', 16));
    put($b, $OFF{red_mask_size}, pack('C', 8));
    put($b, $OFF{red_field_position}, pack('C', 16));
    put($b, $OFF{green_mask_size}, pack('C', 8));
    put($b, $OFF{green_field_position}, pack('C', 8));
    put($b, $OFF{blue_mask_size}, pack('C', 8));
    put($b, $OFF{blue_field_position}, pack('C', 0));
    put($b, $OFF{emu_types}, pack('l<4', -1, 0, 1, 2));

    assert_eq('fbgattr-size', length($b), 88);
    assert_eq('signed-real_type', s32($b, $OFF{real_type}), -7);
    assert_eq('signed-fb_cmsize', s32($b, $OFF{fb_cmsize}), -1);
    assert_eq('signed-flags', s32($b, $OFF{flags}), -2);
    assert_eq('unsigned-origin-x', u16($b, $OFF{terminal_origin_x}), 65535);
    assert_eq('unsigned-pitch', u32($b, $OFF{pitch}), 4800);
    assert_eq('unsigned-red-size', u8($b, $OFF{red_mask_size}), 8);
    assert_eq('emu_types[0]', s32($b, $OFF{emu_types}), -1);

    print "ABI_ONLY=PASS\n";
    print "ABI_SELF_TEST=PASS signed_int32,unsigned_uint32,uint16,uint8\n";
    print "fbgattr_size=88 fbtype_size=24 fbsattr_size=40 gfxfb_info_size=20\n";
    print "offsets: real_type=0 owner=4 fbtype=8 sattr=32 dev_specific=40 emu_types=72\n";
    print "fbtype: fb_type=8 fb_height=12 fb_width=16 fb_depth=20 fb_cmsize=24 fb_size=28\n";
    print "fbsattr: flags=32 emu_type=36 dev_specific[8]=40..71\n";
    print "gfxfb_info overlay: x=40 y=42 pitch=44 font_width=48 font_height=50 red_size=52 red_pos=53 green_size=54 green_pos=55 blue_size=56 blue_pos=57 tail_padding=2\n";
    print "ioctl: FIOC=0x4600 FBIOGATTR=0x4606\n";
    exit 0;
}

sysopen(my $fh, $path, O_RDONLY)
    or die "open($path, O_RDONLY): $!\n";
my $buf = "\0" x $size;
my $ok = ioctl($fh, $cmd, $buf);
if (!defined($ok)) {
    my $e = "$!";
    close($fh);
    die sprintf("FBIOGATTR 0x%04x failed on %s: %s\n", $cmd, $path, $e);
}
close($fh) or die "close($path): $!\n";

# fbgattr contains signed C int fields. gfxfb_info uses fixed-width unsigned
# integers and overlays the first 18 bytes of dev_specific[8].
my $real_type = s32($buf, 0);
my $owner     = s32($buf, 4);
my $fb_type   = s32($buf, 8);
my $fb_height = s32($buf, 12);
my $fb_width  = s32($buf, 16);
my $fb_depth  = s32($buf, 20);
my $fb_cmsize = s32($buf, 24);
my $fb_size   = s32($buf, 28);
my $flags     = s32($buf, 32);
my $emu_type  = s32($buf, 36);
my $g = 40;
my %v = (
    terminal_origin_x => u16($buf, $g + 0),
    terminal_origin_y => u16($buf, $g + 2),
    pitch => u32($buf, $g + 4),
    font_width => u16($buf, $g + 8),
    font_height => u16($buf, $g + 10),
    red_mask_size => u8($buf, $g + 12),
    red_field_position => u8($buf, $g + 13),
    green_mask_size => u8($buf, $g + 14),
    green_field_position => u8($buf, $g + 15),
    blue_mask_size => u8($buf, $g + 16),
    blue_field_position => u8($buf, $g + 17),
);

printf "DEVICE=%s\n", $path;
printf "FBIOGATTR=PASS request=0x%04x buffer_bytes=%d\n", $cmd, length($buf);
printf "ABI fbgattr_size=88 offsets: real_type=0 owner=4 fbtype=8 sattr=32 dev_specific=40 emu_types=72\n";
printf "real_type=%d owner=%d\n", $real_type, $owner;
printf "fb_type=%d fb_height=%d fb_width=%d fb_depth=%d fb_cmsize=%d fb_size=%d\n",
    $fb_type, $fb_height, $fb_width, $fb_depth, $fb_cmsize, $fb_size;
printf "sattr.flags=%d (0x%08x) FB_ATTR_AUTOINIT=%s FB_ATTR_DEVSPECIFIC=%s\n",
    $flags, $flags, ($flags & 1) ? 'SET' : 'clear', ($flags & 2) ? 'SET' : 'clear';
printf "sattr.emu_type=%d\n", $emu_type;
for my $k (qw(terminal_origin_x terminal_origin_y pitch font_width font_height
              red_mask_size red_field_position green_mask_size green_field_position
              blue_mask_size blue_field_position)) {
    printf "%s=%u\n", $k, $v{$k};
}
printf "gfxfb_info_size=20 field_bytes=18 tail_padding=2 dev_specific_capacity=32\n";
printf "dev_specific_raw_hex=%s\n", unpack('H*', substr($buf, 40, 32));
printf "emu_types=%s\n", join(',', map { s32($buf, 72 + 4 * $_) } 0..3);
printf "EXPECTATION: width=%s height=%s depth=%s pitch=%s size=%s\n",
    ($fb_width == 1200) ? 'MATCH' : 'MISMATCH',
    ($fb_height == 1920) ? 'MATCH' : 'MISMATCH',
    ($fb_depth == 32) ? 'MATCH' : 'MISMATCH',
    ($v{pitch} == 4800) ? 'MATCH' : 'MISMATCH',
    ($fb_size == 9216000) ? 'MATCH' : 'MISMATCH';
