#pragma D option quiet
#pragma D option bufsize=4m
#pragma D option switchrate=10hz

/* Run under: dtrace -Z -c '/usr/bin/Xorg ...' -s dtrace.d */
BEGIN
{
    printf("ROTFB_DTRACE_BEGIN target_pid=%d\n", $target);
}

/* DDX static/local functions: arg1 at return is the function result. */
pid$target:illumosfb_drv.so:IlFbProbe*:entry
{ @IlFbProbe_entry = count(); }
pid$target:illumosfb_drv.so:IlFbProbe*:return
{ @IlFbProbe_return = count(); if (arg1 != 0) @IlFbProbe_success = count(); }

pid$target:illumosfb_drv.so:IlFbOpenDev*:entry
{ @IlFbOpenDev_entry = count(); }
pid$target:illumosfb_drv.so:IlFbOpenDev*:return
{
    @IlFbOpenDev_return = count();
    /* int fd is returned in the low 32 bits; cast before testing -1. */
    if ((int)arg1 >= 0) {
        self->rotfb_fd = (int)arg1;
        @IlFbOpenDev_success = count();
        printf("ROTFB_FD=%d\n", (int)arg1);
    }
}

pid$target:illumosfb_drv.so:IlFbPreInit*:entry
{ @IlFbPreInit_entry = count(); }
pid$target:illumosfb_drv.so:IlFbPreInit*:return
{ @IlFbPreInit_return = count(); if (arg1 != 0) @IlFbPreInit_success = count(); }

pid$target:illumosfb_drv.so:IlFbScreenInit*:entry
{ @IlFbScreenInit_entry = count(); }
pid$target:illumosfb_drv.so:IlFbScreenInit*:return
{ @IlFbScreenInit_return = count(); if (arg1 != 0) @IlFbScreenInit_success = count(); }

pid$target:libfb.so:fbScreenInit:entry
{ @fbScreenInit_entry = count(); }
pid$target:libfb.so:fbScreenInit:return
{ @fbScreenInit_return = count(); if (arg1 != 0) @fbScreenInit_success = count(); }

pid$target:libshadow.so:shadowSetup:entry
{ @shadowSetup_entry = count(); }
pid$target:libshadow.so:shadowSetup:return
{ @shadowSetup_return = count(); if (arg1 != 0) @shadowSetup_success = count(); }

pid$target:illumosfb_drv.so:IlFbCreateScreenResources*:entry
{ @IlFbCreateScreenResources_entry = count(); }
pid$target:illumosfb_drv.so:IlFbCreateScreenResources*:return
{ @IlFbCreateScreenResources_return = count(); if (arg1 != 0) @IlFbCreateScreenResources_success = count(); }

/* shadowAdd(ScreenPtr, PixmapPtr, update, window, int randr, closure).
 * The fifth C argument is DTrace arg4. Xorg 1.19.7 explicitly maps the
 * degree value 270 to SHADOW_ROTATE_270 (bit value 8) inside shadowAdd().
 */
pid$target:libshadow.so:shadowAdd:entry
{
    @shadowAdd_entry = count();
    printf("SHADOW_ADD randr_arg4=%d\n", (int)arg4);
    self->shadowadd_rot = arg4;
    if (arg4 == 270) @shadowAdd_rotation_270 = count();
}
pid$target:libshadow.so:shadowAdd:return
{
    @shadowAdd_return = count();
    if (arg1 != 0) @shadowAdd_success = count();
    if (arg1 != 0 && self->shadowadd_rot == 270) @shadowAdd_270_success = count();
    self->shadowadd_rot = 0;
}

pid$target:illumosfb_drv.so:IlFbRotateUpdate*:entry
{ @IlFbRotateUpdate_entry = count(); }
pid$target:illumosfb_drv.so:IlFbRotateUpdate*:return
{ @IlFbRotateUpdate_return = count(); }
pid$target:libshadow.so:shadowUpdateRotate32_270:entry
{
    @shadowUpdateRotate32_270_entry = count();
    self->rotfb_rotate_active = 1;
}
pid$target:libshadow.so:shadowUpdateRotate32_270:return
{
    @shadowUpdateRotate32_270_return = count();
    self->rotfb_rotate_active = 0;
}

pid$target:illumosfb_drv.so:IlFbWindowLinear*:entry
{
    @IlFbWindowLinear_entry = count();
    self->rotfb_window_mode = arg3;
    if (arg3 == 4) @IlFbWindowLinear_write_mode = count();
}
pid$target:illumosfb_drv.so:IlFbWindowLinear*:return
{
    @IlFbWindowLinear_return = count();
    if (arg1 != 0) @IlFbWindowLinear_nonnull = count();
    if (arg1 != 0 && self->rotfb_window_mode == 4 &&
        self->rotfb_rotate_active == 1) {
        @physical_fb_destinations_during_rotate = count();
    }
    self->rotfb_window_mode = 0;
}

/* Remember the framebuffer fd returned by IlFbOpenDev; correlate syscalls. */
syscall::ioctl:entry
/arg0 == self->rotfb_fd && arg1 == 0x4b0a && arg2 == 1/
{
    self->rotfb_kdgraphics = 1;
    @KDSETMODE_GRAPHICS_entry = count();
    printf("KDSETMODE_GRAPHICS_ENTRY\n");
}
syscall::ioctl:return
/self->rotfb_kdgraphics/
{
    @KDSETMODE_GRAPHICS_return = count();
    if (errno == 0) {
        @KDSETMODE_GRAPHICS_success = count();
        printf("KDSETMODE_GRAPHICS_SUCCESS\n");
    }
    printf("KDSETMODE_GRAPHICS errno=%d syscall_ret=%d\n", errno, (int)arg0);
    self->rotfb_kdgraphics = 0;
}

syscall::ioctl:entry
/arg0 == self->rotfb_fd && arg1 == 0x4b0a && arg2 == 0/
{
    self->rotfb_kdtext = 1;
    @KDSETMODE_TEXT_entry = count();
    printf("KDSETMODE_TEXT_ENTRY\n");
}
syscall::ioctl:return
/self->rotfb_kdtext/
{
    @KDSETMODE_TEXT_return = count();
    if (errno == 0) {
        @KDSETMODE_TEXT_success = count();
        printf("KDSETMODE_TEXT_SUCCESS\n");
    }
    printf("KDSETMODE_TEXT errno=%d syscall_ret=%d\n", errno, (int)arg0);
    self->rotfb_kdtext = 0;
}

/* illumos amd64 mmap(2): addr,len,prot,flags,fd,off. */
syscall::mmap:entry
/arg4 == self->rotfb_fd && arg1 == 9216000/
{
    self->rotfb_fb_mmap = 1;
    @fb_mmap_entry = count();
}
syscall::mmap:return
/self->rotfb_fb_mmap/
{
    @fb_mmap_return = count();
    if (errno == 0) {
        @fb_mmap_success = count();
        printf("FB_MMAP_SUCCESS\n");
    }
    printf("FB_MMAP errno=%d ret0=0x%llx ret1=0x%llx\n", errno, arg0, arg1);
    self->rotfb_fb_mmap = 0;
}
/* Some large-file ABIs expose the same operation as mmap64. */
syscall::mmap64:entry
/arg4 == self->rotfb_fd && arg1 == 9216000/
{
    self->rotfb_fb_mmap = 1;
    @fb_mmap64_entry = count();
}
syscall::mmap64:return
/self->rotfb_fb_mmap/
{
    @fb_mmap64_return = count();
    if (errno == 0) {
        @fb_mmap64_success = count();
        printf("FB_MMAP64_SUCCESS\n");
    }
    printf("FB_MMAP64 errno=%d ret0=0x%llx ret1=0x%llx\n", errno, arg0, arg1);
    self->rotfb_fb_mmap = 0;
}

END
{
    printf("\n===== ROTFB RUN11 DTRACE COUNTS =====\n");
    printa("IlFbProbe entry=%@d\n", @IlFbProbe_entry);
    printa("IlFbProbe return=%@d\n", @IlFbProbe_return);
    printa("IlFbProbe success=%@d\n", @IlFbProbe_success);
    printa("IlFbOpenDev entry=%@d\n", @IlFbOpenDev_entry);
    printa("IlFbOpenDev return=%@d\n", @IlFbOpenDev_return);
    printa("IlFbOpenDev success=%@d\n", @IlFbOpenDev_success);
    printa("IlFbPreInit entry=%@d\n", @IlFbPreInit_entry);
    printa("IlFbPreInit return=%@d\n", @IlFbPreInit_return);
    printa("IlFbPreInit success=%@d\n", @IlFbPreInit_success);
    printa("IlFbScreenInit entry=%@d\n", @IlFbScreenInit_entry);
    printa("IlFbScreenInit return=%@d\n", @IlFbScreenInit_return);
    printa("IlFbScreenInit success=%@d\n", @IlFbScreenInit_success);
    printa("fbScreenInit entry=%@d\n", @fbScreenInit_entry);
    printa("fbScreenInit return=%@d\n", @fbScreenInit_return);
    printa("fbScreenInit success=%@d\n", @fbScreenInit_success);
    printa("shadowSetup entry=%@d\n", @shadowSetup_entry);
    printa("shadowSetup return=%@d\n", @shadowSetup_return);
    printa("shadowSetup success=%@d\n", @shadowSetup_success);
    printa("IlFbCreateScreenResources entry=%@d\n", @IlFbCreateScreenResources_entry);
    printa("IlFbCreateScreenResources return=%@d\n", @IlFbCreateScreenResources_return);
    printa("IlFbCreateScreenResources success=%@d\n", @IlFbCreateScreenResources_success);
    printa("shadowAdd entry=%@d\n", @shadowAdd_entry);
    printa("shadowAdd rotation270=%@d\n", @shadowAdd_rotation_270);
    printa("shadowAdd return=%@d\n", @shadowAdd_return);
    printa("shadowAdd success=%@d\n", @shadowAdd_success);
    printa("shadowAdd success270=%@d\n", @shadowAdd_270_success);
    printa("IlFbRotateUpdate entry=%@d\n", @IlFbRotateUpdate_entry);
    printa("IlFbRotateUpdate return=%@d\n", @IlFbRotateUpdate_return);
    printa("shadowUpdateRotate32_270 entry=%@d\n", @shadowUpdateRotate32_270_entry);
    printa("shadowUpdateRotate32_270 return=%@d\n", @shadowUpdateRotate32_270_return);
    printa("IlFbWindowLinear entry=%@d\n", @IlFbWindowLinear_entry);
    printa("IlFbWindowLinear write_mode=%@d\n", @IlFbWindowLinear_write_mode);
    printa("IlFbWindowLinear return=%@d\n", @IlFbWindowLinear_return);
    printa("IlFbWindowLinear nonnull=%@d\n", @IlFbWindowLinear_nonnull);
    printa("physical_fb_destinations_during_rotate=%@d\n", @physical_fb_destinations_during_rotate);
    printa("KDSETMODE_GRAPHICS entry=%@d\n", @KDSETMODE_GRAPHICS_entry);
    printa("KDSETMODE_GRAPHICS return=%@d\n", @KDSETMODE_GRAPHICS_return);
    printa("KDSETMODE_GRAPHICS success=%@d\n", @KDSETMODE_GRAPHICS_success);
    printa("KDSETMODE_TEXT entry=%@d\n", @KDSETMODE_TEXT_entry);
    printa("KDSETMODE_TEXT return=%@d\n", @KDSETMODE_TEXT_return);
    printa("KDSETMODE_TEXT success=%@d\n", @KDSETMODE_TEXT_success);
    printa("fb_mmap entry=%@d\n", @fb_mmap_entry);
    printa("fb_mmap return=%@d\n", @fb_mmap_return);
    printa("fb_mmap success=%@d\n", @fb_mmap_success);
    printa("fb_mmap64 entry=%@d\n", @fb_mmap64_entry);
    printa("fb_mmap64 return=%@d\n", @fb_mmap64_return);
    printa("fb_mmap64 success=%@d\n", @fb_mmap64_success);
}
