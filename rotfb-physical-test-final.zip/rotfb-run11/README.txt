ROTFB RUN #11 — FINAL PHYSICAL TEST HARNESS
===========================================

Immutable production DDX baseline
----------------------------------
Source commit: 3f4e8e42eb9b58418eb6e70c54971f99fb778b6a
Source branch: gop-rotation-hook
DDX SHA256: db845048abf8ba0245ff45a023c0ca9b28f5488b442274d7955e52a560e25720
Target: Chuwi MiniBook X N150, OpenIndiana Hipster 2026.10
Physical framebuffer: 1200x1920, BGRA32, pitch 4800, size 9216000
Logical X surface: 1920x1200; rotation argument: 270 degrees

This harness does not rebuild or modify the DDX. It does not modify /etc/X11,
IPS packages, kernel, boot environment, EFI, UEFI variables, or system DDX.
The system helper modules libfb.so and libshadow.so are loaded from their
existing /usr/lib/xorg/modules/amd64 paths. The system driver directory is not
in ModulePath. The only DDX copy is in this temporary kit.

Files
-----
preflight.sh                    read-only checks and recovery baseline snapshot
launch.sh                       gated private Xorg + DTrace launch
cleanup.sh                      graceful Xorg stop and explicit recovery gate
common.sh                       shared fuser/nm/DTrace parsers
xorg.conf                       private DDX, /dev/fb0, ShadowFB, 1920x1200
modules/drivers/amd64/illumosfb_drv.so  immutable Run #11 DDX
rotfb-fbgattr-detail-probe.pl   one FBIOGATTR read-only decoder
abi-layout-check.c              amd64 sizeof/offsetof assertions
dtrace.d                        DDX/libfb/libshadow/ioctl/mmap probes
rotfb-asymmetric-test.png        1920x1200 asymmetric visual test pattern
SHA256SUMS                       complete file integrity manifest
VERIFICATION.txt                evidence and limitations

Stage 0 — extract
-----------------
On the Chuwi, as root:

  mkdir -p /var/tmp
  unzip -o rotfb-physical-test-final.zip -d /var/tmp

The archive contains the top-level directory rotfb-run11, so the installed
paths must begin with /var/tmp/rotfb-run11/.

Do not copy the DDX into /usr/lib. Do not install packages. Do not change the
active BE or any system configuration.

Stage 1 — preflight while LightDM is still running
--------------------------------------------------
Open TWO independent root shells. Keep the recovery shell open on SSH or a
serial console throughout the test; do not use the VT that will run Xorg.
Verify /dev/console is available. Identify the exact active display-manager
FMRI and the one stock Xorg PID. Example discovery commands:

  svcs -a | grep -i 'lightdm\|display'
  pgrep -x Xorg
  ps -p <PID> -o args=

Run from the root operator shell (replace FMRI and PID with actual values):

  ROTFB_DM_FMRI='svc:/application/graphical-login/lightdm:default' \
  ROTFB_VT=8 /var/tmp/rotfb-run11/preflight.sh <STOCK_XORG_PID>

The FMRI above is only an example; use the exact service on this machine.
The script will refuse to proceed unless the service is online, the stock
Xorg PID is the only Xorg, its current VT is captured, the distinct selected VT
exists and fuser classifies it as free, and an independent recovery shell is
explicitly confirmed.

The preflight performs exactly one detailed FBIOGATTR query. It also runs the
Perl ABI self-test, validates nm -P local function rows, checks syscall ioctl
and mmap/mmap64 entry/return probes, resolves stock-Xorg PID probes for
libfb/libshadow, and compiles dtrace.d in compile-only mode with a harmless
/usr/bin/true target. It does not stop LightDM, start Xorg, mmap /dev/fb0,
write framebuffer memory, or change KDSETMODE.

fuser handling
--------------
The shared helper uses the illumos /usr/sbin/fuser (or /usr/bin/fuser) with
-f. It distinguishes:
  FREE   no process owners and no kernel consumers
  BUSY   process owner(s) or a reported kernel consumer
  ERROR  permission, lookup, invocation, or other inspection failure

A blank PID list plus successful fuser exit and only the normal pathname header
is FREE; a nonzero fuser status is ERROR. The pathname header itself is normal
fuser output, not a diagnostic failure. The helper captures stdout, stderr,
and exit status separately. A kernel consumer is not silently
ignored; it blocks launch until its meaning is known. The fuser fixtures exercise all classifications; actual OpenIndiana fuser
behavior against a device node remains a VM/target check. The final preflight
still validates the exact selected VT on the physical Chuwi.

Stage 2 — manually release LightDM
----------------------------------
Only after PREFLIGHT=PASS:

  svcadm disable -t '<EXACT_DISPLAY_MANAGER_FMRI>'

Wait for the stock Xorg to exit. Do not start a second Xorg. Keep the recovery
shell open. Do not proceed if the service did not become disabled, Xorg remains
alive, /dev/fb0 is busy, or the selected VT is not free.

Stage 3 — launch Run #11
-----------------------
Use the same operator TTY and selected VT recorded by preflight:

  ROTFB_VT=8 /var/tmp/rotfb-run11/launch.sh

The script rechecks the baseline, exact DDX SHA256, LightDM disabled state,
Xorg process list, framebuffer and VT ownership, display lock/socket, and
requires START-RUN11. It runs Xorg :1 on the selected VT under DTrace. ModulePath
contains only the private DDX root and the system helper-module directory; the
system DDX driver directory is omitted. Xorg's log must name the private DDX
and both expected helper module paths, and the DDX hash is checked again.

The launch script persists DTrace PID and later the exact Xorg PID before it
can report module-path acceptance. If startup fails after process creation,
run cleanup.sh before considering LightDM restoration. Never start LightDM on
top of a possibly live Xorg.

Stage 4 — runtime acceptance gates
----------------------------------
Treat every gate independently; a loader test or a successful process start is
not a ScreenInit PASS:

1. Private Run #11 DDX path in Xorg log and matching SHA256.
2. IlFbProbe returns TRUE.
3. IlFbOpenDev returns a valid fd.
4. IlFbPreInit returns TRUE.
5. mmap of exactly 9216000 bytes on the DDX framebuffer fd succeeds.
6. KDSETMODE(KD_GRAPHICS) ioctl succeeds.
7. IlFbScreenInit returns TRUE.
8. fbScreenInit and shadowSetup return TRUE.
9. shadowAdd receives arg4=270 and returns TRUE.
10. shadowUpdateRotate32_270 is entered and returns.
11. IlFbWindowLinear returns non-NULL destinations in
    SHADOW_WINDOW_WRITE mode while the 270-degree helper is active.

The Xorg 1.19.7 signature is:
  shadowAdd(ScreenPtr, PixmapPtr, ShadowUpdateProc, ShadowWindowProc,
            int randr, void *closure) -> Bool
The fifth C argument is DTrace arg4. The script records it on entry and
correlates it with a successful return. Xorg 1.19.7 maps randr=270 to
SHADOW_ROTATE_270. shadowUpdateRotate32_270 returns void.

The final window callback gate proves that the rotation helper requested a
write destination and received a non-NULL framebuffer mapping pointer. It is
strong runtime evidence for the store path, but DTrace does not independently
read back the framebuffer bytes. Record this distinction; do not claim a
separate memory readback unless one is actually performed.

Local DDX functions are listed by nm -P before launch. PID-provider resolution
for those local symbols is not inferred from nm: it is confirmed only by
nonzero runtime counts after the DDX is loaded. The DTrace script uses -Z so
missing probes do not abort Xorg; a zero/missing count is NOT PASS.

Stage 5 — visual orientation
----------------------------
Display rotfb-asymmetric-test.png using an image viewer already installed on
the target; do not install anything. The logical test image is 1920x1200. For
  PhysicalX = 1199 - LogicalY
  PhysicalY = LogicalX
logical TL -> physical TR; logical TR -> physical BR; logical BL -> physical TL;
logical BR -> physical BL. Physical rotation PASS requires direct inspection
of the Chuwi panel. Xorg logs and DTrace counts alone cannot establish it.

Stage 6 — cleanup and restore
-----------------------------
From the independent recovery shell if needed, run:

  /var/tmp/rotfb-run11/cleanup.sh

Cleanup sends SIGTERM only to the recorded Xorg PID and never SIGKILLs. It
waits for Xorg and DTrace exit, requires DTrace evidence of KD_TEXT restoration
when KD_GRAPHICS was observed, checks that /dev/fb0 and the test VT have no
fuser owners, then archives the run state. If the DTrace log cannot prove the
text-mode transition, inspect the physical console manually and rerun with:

  ROTFB_KDTEXT_CONFIRMED=YES /var/tmp/rotfb-run11/cleanup.sh

That override is an explicit operator attestation, not DTrace proof. If Xorg
hangs, cleanup does not force-kill it and does not restore LightDM. Use the
independent recovery shell; if the console cannot be recovered, reboot. Since
this kit makes no persistent system changes, reboot restores the normal boot
configuration. After successful cleanup, restore only the exact recorded FMRI using a
temporary SMF enable (the preflight state was online and `disable -t` was used):

  /var/tmp/rotfb-run11/cleanup.sh '<EXACT_DISPLAY_MANAGER_FMRI>'

Do not restore a different service. Confirm LightDM/Xorg and the normal VT are
usable after restoration.

What this kit does not claim
----------------------------
* CI or VM tests do not prove physical panel rotation.
* DDX ELF symbol presence does not prove runtime PID probe hits.
* A DTrace callback destination does not independently prove memory readback.
* A clean Xorg exit alone does not prove KD_TEXT restoration.
* A prepared image is not proof that it was displayed.

The physical test remains pending until the runtime gates, visible orientation,
and cleanup/recovery are recorded from the actual Chuwi.
