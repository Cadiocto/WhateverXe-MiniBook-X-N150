#!/bin/sh
set -eu
BASE=${ROTFB_BASE:-/var/tmp/rotfb-run11}
DDX="$BASE/modules/drivers/amd64/illumosfb_drv.so"
EXPECTED_SHA=db845048abf8ba0245ff45a023c0ca9b28f5488b442274d7955e52a560e25720
VT=${ROTFB_VT:-8}
VTDEV="/dev/vt/$VT"
CONF="$BASE/xorg.conf"
DTRACE_SCRIPT="$BASE/dtrace.d"
PROBE="$BASE/rotfb-fbgattr-detail-probe.pl"
BASELINE="$BASE/baseline.state"
OUT="$BASE/preflight-$(date +%Y%m%d-%H%M%S).log"

. "$BASE/common.sh"
mkdir -p "$BASE"
exec >"$OUT" 2>&1
fail() { echo "BLOCKED: $*"; echo "PREFLIGHT=FAIL"; exit 1; }
pass() { echo "PASS: $*"; }

[ "$(id -u)" -eq 0 ] || fail "run from a root shell"
[ -x /usr/bin/Xorg ] || fail "/usr/bin/Xorg missing"
[ -c /dev/console ] || fail "/dev/console unavailable; no independent console recovery path"
[ -f "$DDX" ] || fail "Run #11 DDX missing: $DDX"
[ -f "$CONF" ] && [ -f "$DTRACE_SCRIPT" ] && [ -f "$PROBE" ] || fail "physical kit is incomplete"
[ -f "$BASE/common.sh" ] || fail "common helper missing"
[ ! -e "$BASE/run.state" ] || fail "an earlier run.state exists; inspect it before proceeding"
[ ! -e "$BASE/baseline.state" ] || fail "baseline.state already exists; preserve it and use a fresh extracted kit"

XORG_VERSION=$(/usr/bin/Xorg -version 2>&1 || true)
printf '%s\n' "$XORG_VERSION" > "$BASE/xorg-version.txt"
printf '%s\n' "$XORG_VERSION" | grep -F '1.19.7' >/dev/null || fail "target Xorg is not 1.19.7"
pass "target Xorg version is 1.19.7"

ACTUAL_SHA=$(digest -a sha256 "$DDX" | awk '{print $1}')
[ "$ACTUAL_SHA" = "$EXPECTED_SHA" ] || fail "Run #11 DDX SHA256 mismatch: $ACTUAL_SHA"
pass "Run #11 DDX SHA256=$ACTUAL_SHA"

[ -f /usr/lib/xorg/modules/amd64/libfb.so ] || fail "system libfb.so missing"
[ -f /usr/lib/xorg/modules/amd64/libshadow.so ] || fail "system libshadow.so missing"
pass "system helper modules exist at /usr/lib/xorg/modules/amd64"

for needle in \
    'Driver "illumosfb"' \
    'Option "Device" "/dev/fb0"' \
    'Option "ShadowFB" "true"' \
    'Modes "current"' \
    'Virtual 1920 1200' \
    'ModulePath "/var/tmp/rotfb-run11/modules,/usr/lib/xorg/modules/amd64"'; do
    grep -F "$needle" "$CONF" >/dev/null || fail "xorg.conf missing required directive: $needle"
done
if grep -F 'ModulePath "/usr/lib/xorg/modules"' "$CONF" >/dev/null; then
    fail "xorg.conf exposes the system DDX driver directory"
fi
pass "private DDX ModulePath, system helper path, /dev/fb0, ShadowFB and 1920x1200 mode validated"

PERL=$(command -v perl) || fail "Perl missing"
"$PERL" -c "$PROBE" > "$BASE/fbgattr-perl-syntax.txt" 2>&1 || fail "FBIOGATTR Perl syntax failed"
"$PERL" "$PROBE" --abi-only > "$BASE/fbgattr-abi-selftest.txt" 2>&1 || fail "FBIOGATTR ABI self-test failed"
"$PERL" "$PROBE" /dev/fb0 > "$BASE/fbgattr-detail.txt" 2>&1 || fail "single read-only FBIOGATTR query failed"
grep -F 'EXPECTATION: width=MATCH height=MATCH depth=MATCH pitch=MATCH size=MATCH' "$BASE/fbgattr-detail.txt" >/dev/null || fail "FBIOGATTR geometry/pitch/size mismatch"
pass "single FBIOGATTR read decoded 1200x1920x32, pitch 4800, size 9216000"

NM=/usr/bin/nm
[ -x "$NM" ] || fail "/usr/bin/nm missing"
"$NM" -P "$DDX" > "$BASE/ddx.nm-P.txt" 2>&1 || fail "/usr/bin/nm -P failed"
for sym in IlFbProbe IlFbOpenDev IlFbPreInit IlFbScreenInit IlFbCreateScreenResources IlFbRotateUpdate IlFbWindowLinear; do
    rotfb_nm_has_text_symbol "$BASE/ddx.nm-P.txt" "$sym" || fail "local text function missing from nm -P output: $sym"
done
pass "all seven DDX local text functions verified using Solaris nm -P output"

DTRACE=$(command -v dtrace) || fail "DTrace executable missing"
for spec in 'ioctl entry' 'ioctl return'; do
    set -- $spec; name=$1; probe_name=$2
    tmp="$BASE/dtrace-list-$name-$probe_name.txt"
    "$DTRACE" -l -n "syscall::$name:$probe_name" > "$tmp" 2>&1 || fail "DTrace cannot list syscall::$name:$probe_name"
    rotfb_dtrace_has_probe "$tmp" syscall "" "$name" "$probe_name" || fail "syscall probe not present: $name:$probe_name"
done
MMAP_NAME=
for name in mmap mmap64; do
    e="$BASE/dtrace-list-$name-entry.txt"; r="$BASE/dtrace-list-$name-return.txt"
    if "$DTRACE" -l -n "syscall::$name:entry" > "$e" 2>&1 && \
       "$DTRACE" -l -n "syscall::$name:return" > "$r" 2>&1 && \
       rotfb_dtrace_has_probe "$e" syscall "" "$name" entry && \
       rotfb_dtrace_has_probe "$r" syscall "" "$name" return; then
        MMAP_NAME=$name; break
    fi
done
[ -n "$MMAP_NAME" ] || fail "neither mmap nor mmap64 entry/return pair is available"
pass "syscall ioctl entry/return and $MMAP_NAME entry/return resolve"

XORG_PID=${1:-${ROTFB_STOCK_XORG_PID:-}}
[ -n "$XORG_PID" ] || fail "usage: ROTFB_DM_FMRI=... ROTFB_VT=N preflight.sh <stock-Xorg-PID>"
case "$XORG_PID" in *[!0-9]*|'') fail "invalid Xorg PID: $XORG_PID";; esac
kill -0 "$XORG_PID" 2>/dev/null || fail "stock Xorg PID $XORG_PID is not running"
XORG_LIST=$(pgrep -x Xorg 2>/dev/null || true)
[ "$XORG_LIST" = "$XORG_PID" ] || fail "expected exactly one stock Xorg PID=$XORG_PID; pgrep reports ${XORG_LIST:-none}"

[ -c "$VTDEV" ] || fail "selected VT device does not exist: $VTDEV"
rotfb_fuser_check "$VTDEV" "VT $VTDEV" || fail "fuser could not determine VT ownership"
[ "$ROTFB_FUSER_RESULT" = FREE ] || fail "selected VT $VTDEV is occupied"
pass "fuser classifies selected VT as FREE (empty process list is not treated as an error)"

for spec in 'libfb.so fbScreenInit' 'libshadow.so shadowSetup' 'libshadow.so shadowAdd' 'libshadow.so shadowUpdateRotate32_270'; do
    set -- $spec; mod=$1; fn=$2
    for name in entry return; do
        tmp="$BASE/dtrace-pid-${mod}-${fn}-${name}.txt"
        "$DTRACE" -l -p "$XORG_PID" -n "pid$XORG_PID:$mod:$fn:$name" > "$tmp" 2>&1 || fail "PID provider cannot resolve pid$XORG_PID:$mod:$fn:$name"
        rotfb_dtrace_has_probe "$tmp" "pid$XORG_PID" "$mod" "$fn" "$name" || fail "PID probe row not found: pid$XORG_PID:$mod:$fn:$name"
    done
done
pass "stock-Xorg PID entry/return probes resolve for fbScreenInit, shadowSetup, shadowAdd and shadowUpdateRotate32_270"

"$DTRACE" -e -Z -c /usr/bin/true -s "$DTRACE_SCRIPT" > "$BASE/dtrace-compile.txt" 2>&1 || fail "DTrace compile-only rejected dtrace.d"
pass "DTrace compile-only succeeded with -e -Z and harmless /usr/bin/true target"

TTY=$(rotfb_current_tty) || fail "root operator shell has no controlling terminal"
case "$TTY" in /dev/vt/*) fail "operator shell is attached to a VT that may be taken over; use a separate SSH/serial recovery shell";; esac
SHELL_PID=$PPID
kill -0 "$SHELL_PID" 2>/dev/null || fail "cannot verify the invoking root shell PID"
DM_FMRI=${ROTFB_DM_FMRI:-}
[ -n "$DM_FMRI" ] || fail "set ROTFB_DM_FMRI to the exact active display-manager FMRI"
SVCS=$(command -v svcs) || fail "svcs missing; cannot snapshot display-manager state"
DM_STATE=$($SVCS -H -o state "$DM_FMRI" 2>/dev/null | sed -n '1p')
[ "$DM_STATE" = online ] || fail "display manager $DM_FMRI is not online (state=${DM_STATE:-unknown})"
DM_FMRI=$(printf '%s' "$DM_FMRI" | tr -d '\n')
XORG_ARGS=$(ps -p "$XORG_PID" -o args= 2>/dev/null || true)
[ -n "$XORG_ARGS" ] || fail "cannot snapshot stock Xorg command line"
STOCK_VT=$(printf '%s\n' "$XORG_ARGS" | sed -n 's/.*[[:space:]]vt\([0-9][0-9]*\).*/\1/p' | sed -n '1p')
[ -n "$STOCK_VT" ] || fail "cannot identify the stock Xorg VT from its command line"
[ "$STOCK_VT" != "$VT" ] || fail "selected test VT is the current stock Xorg VT"

printf 'BASELINE_VERSION=1\nSTOCK_XORG_PID=%s\nSTOCK_XORG_ARGS=%s\nSTOCK_XORG_VT=%s\nSELECTED_VT=%s\nOPERATOR_SHELL_PID=%s\nOPERATOR_TTY=%s\nDM_FMRI=%s\nDM_STATE=%s\n' \
    "$XORG_PID" "$XORG_ARGS" "$STOCK_VT" "$VT" "$SHELL_PID" "$TTY" "$DM_FMRI" "$DM_STATE" > "$BASELINE"
chmod 600 "$BASELINE"
echo "A separate root recovery shell on $TTY and /dev/console are available."
echo "Keep that recovery shell open throughout the test."
printf 'Type RECOVERY-SHELL-READY to confirm you have a second independent root session: '
read ACK
[ "$ACK" = RECOVERY-SHELL-READY ] || fail "independent recovery shell was not confirmed"
pass "baseline captured: Xorg PID, command line/current VT, selected VT, operator shell/TTY and exact online service FMRI"
echo "PREFLIGHT=PASS"
echo "BASELINE=$BASELINE"
echo "LOG=$OUT"
echo "NEXT: manually disable only $DM_FMRI with svcadm disable -t; do not stop it before this point."
