# ⚠️ REFUTED — read this first

**This hypothesis is WRONG.** An agent mounted the *shipped* `boot_archive` from
`usb-image-20260909b` and measured `/etc/path_to_inst` inside it: **0 bytes, 0 lines, zero `kb8042`
entries.**

Mechanism: `oi-make-livecd.sh:483` does copy the file, but **`:560` then does
`: > "$RDROOT/etc/path_to_inst"` unconditionally** (commit `90dec1a3dc`), and the `[ -f ] ||` guard at
`:1047` makes its later `cp` a no-op. Independently verified — the comment there even explains the
intent: *"assignments for whatever hardware it actually boots on (standard illumos install-media
behavior)."*

So the X1 booted with an **empty** `path_to_inst`, and a stale PS/2 `kb8042` pin cannot explain the
dead keyboard.

**The `usbkbm`/`kbtrans` STREAMS-module hypothesis is also refuted** by the same inspection: `usbkbm`,
`usbms`, `usb_ah`, `kbtrans`, `consconfig`, `consconfig_dacf` and the `sad`/`hid`/`conskbd`/`consms`
drivers are **all present** in the shipped ramdisk.

**The actual defect found instead** — the hardcoded 12-name `/dev` allowlist at `oi-make-livecd.sh:450`
which omits `/dev/zfs` and `/dev/sad` — is documented in `docs/x1-dev-node-allowlist.md`.

**Why this document is kept:** the reasoning was plausible and cost real time; leaving the refutation
attached to it stops the next reader re-deriving it. The lesson is in the postscript at the bottom.

---

# The keyboard fault: `/etc/path_to_inst` is per-machine state copied onto removable media

## Status of this document

**REFUTED BY MEASUREMENT. Do not act on this hypothesis.** Retained as a record of the
reasoning and of how it failed, per the project rule that a retraction belongs at the SOURCE
rather than only in the document that supersedes it.

The fix this document proposes was **already in the shipped media**. The 2026-09-09 "b"
boot_archive was mounted and read directly:

```
/etc/path_to_inst  =  0 bytes, 0 lines, zero occurrences of kb8042
```

`oi-make-livecd.sh:483` does copy the host's file, but `:560` then truncates it
**unconditionally** (`: > "$RDROOT/etc/path_to_inst"`, landed in commit `90dec1a3dc`), and the
`[ -f ... ] ||` guard at `:1047` makes the later `cp` a no-op. So the X1 booted with an EMPTY
`path_to_inst`, and a stale PS/2 `kb8042` pin **cannot** be the keyboard cause.

The copy-then-truncate contradiction has since been removed: `path_to_inst` is no longer in
the copy list, it is created empty in one place, and a build gate asserts it ships at 0 bytes.

**The keyboard fault remains unexplained.** Also refuted, by the same inspection: the
competing "missing STREAMS modules" hypothesis -- `usbkbm`, `kbtrans`, `consconfig`,
`consconfig_dacf`, `hid`, `conskbd` and `consms` were all already present on the media.

What this document got RIGHT, and what turned out to matter: the **bug class**. "Build-host
state copied to media, silently wrong on the target" was the correct lens, and its closing
advice -- audit the whole list rather than fixing one entry -- found the real defect one
directory over, in the hardcoded 13-name `/dev` allowlist that shipped no `/dev/zfs` and no
`/dev/sad/user`. See `artifacts/install-media/usb-image-20260909c/README.md`.

What it got WRONG, and the transferable lesson: it reasoned from the SOURCE of the build
script instead of reading the ARTIFACT the script produced. One `lofiadm` + `mount` would
have refuted it in two minutes.

---

## Original hypothesis (retained for the record; REFUTED above)

## What was ruled out first

The previous agent's dying thought was that `pit_is_broken=1` — an AWS Nitro workaround — leaks onto
the X1 and breaks the timer. **Traced and refuted:**

* `apic_calibrate_use_pit = 0` by default (`apic_common.c:147`), so the `panic("Failed to calibrate
  APIC due to broken PIT")` at `:1299` is unreachable and calibration uses the **TSC** path.
* `pit_is_broken` is **self-detecting** anyway (`tscc_pit.c:120`): the kernel probes the PIT and sets
  the flag when the counter never changes. Forcing it in `/etc/system` skips a probe whose outcome
  wouldn't change the calibration source.

So it is untidy — an AWS tunable riding onto a laptop — but **not the cause**.

## The actual suspect

`scripts/oi-make-livecd.sh:483` copies these verbatim from the build host:

```
name_to_major name_to_sysnum driver_aliases driver_classes minor_perm
system path_to_inst vfstab nsswitch.conf passwd shadow group hosts netconfig
```

`/etc/path_to_inst` is **per-machine kernel state**. Its own header says so:

```
#	Caution! This file contains critical kernel state
```

On the EC2/QEMU-shaped build host it contains **33 lines, zero USB/HID entries**, and pins:

```
"/pci@0,0/isa@1/i8042@1,60/keyboard@0"  0  "kb8042"
"/pci@0,0/isa@1/i8042@1,60/mouse@1"     0  "mouse8042"
```

That is a **PS/2 keyboard at a device path the X1 does not have.** The X1's keyboard is USB HID behind
xHCI (`/pci@0,0/pci17aa,2267@14/...`), a path this file never anticipated — while console-keyboard
instance 0 is already claimed by a nonexistent PS/2 node.

## Why this fits the evidence better than a descriptor problem

| observation | explained? |
|---|---|
| the keyboard works at the loader `ok` prompt | ✅ firmware input, no illumos device tree involved |
| **two unrelated keyboards fail identically** | ✅ common factor is our media, not the descriptors |
| `hid` is present and correctly bound (`hid "usbif,class3"`) | ✅ binding is fine; instancing is not |
| `usba`/`xhci` work (USB stick read, `blkdev0` online) | ✅ USB stack is healthy |
| QEMU never shows it | ✅ QEMU **has** a PS/2 `kb8042`, so the copied file is *correct* there |

That last row is the tell. The file is accurate for every machine we have ever tested on and wrong for
the first real laptop.

## The fix

**Do not copy `path_to_inst` onto removable install media.** It is regenerated by `devfsadm` at boot;
shipping a foreign copy actively misinforms the kernel. Review `name_to_major` the same way — instance
*ordering* is also host-specific, though absence of a driver there is a harder failure.

## How to confirm

Rebuild without `path_to_inst`, boot on the X1, and see whether the keyboard attaches. **QEMU cannot
confirm this** — it has the PS/2 hardware the file describes, so it will pass either way. Third time
this session the emulator has been systematically more permissive than the target, after the 820 MiB
staging allocation and the PS/2-vs-USB keyboard path itself.

## Bug class

Same as the `readlink` defect that silently dropped all 13 `/dev` nodes: **build-host state copied to
media, silently wrong on the target.** Worth auditing the whole `for f in ...` list at line 483 with
that lens rather than fixing one entry.


---

## Postscript: why this was wrong, and what would have caught it sooner

I reasoned from `oi-make-livecd.sh:483` (the copy) and never looked at `:560` (the truncation) — I read
the source that *creates* the problem and not the source that *undoes* it. One `grep` for
`path_to_inst` across the whole script, rather than reading the copy loop and stopping, would have
shown both lines immediately.

Worse, the artifact was sitting on disk the entire time. **The shipped `boot_archive` is the ground
truth about what the X1 booted**, and I had it locally. Inspecting the artifact beats reasoning about
the build that produced it — the fourth instance this campaign of measuring the wrong object (after the
VM ACPI tables, `objcopy`-on-dixi, and the stale July `.iso`).
