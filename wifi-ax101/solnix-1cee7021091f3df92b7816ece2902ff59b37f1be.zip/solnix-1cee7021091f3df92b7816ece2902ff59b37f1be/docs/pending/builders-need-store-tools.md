# The builders assume an OpenIndiana build host; a solnix system cannot build solnix packages

Measured on the X1 (dixi, solnix-3), 2026-10-09, by stream I1:
`nix build .#packages.x86_64-solaris.gzip` fails in 13 s with
`bash: line 5: sha256sum: command not found`.

## Why

mk-src-pkg.nix (and mk-userland-pkg.nix, toolchains.nix, gcc-src.nix, base-src.nix,
nix224.nix, host-pkgs.nix' writers, ...) run `builder = "/usr/bin/bash"` with
`PATH=/usr/gnu/bin:/usr/bin:/usr/sbin` and call GNU tools by those paths:
sha256sum, gmake, GNU sed/tar/grep, gcc from /usr/gcc/14. On the OpenIndiana build
host (bhost) those come from IPS packages. A solnix system has no /usr/gnu and no
/usr/gcc, and its /usr/bin is the system profile, so none of them exists there. The
paths in dixi's store that came from these builders were copied in from bhost, not
built on dixi.

So "nix-build works" holds only on an OpenIndiana host: the north star (solnix is
exactly Nix: every package a real derivation that builds where Nix runs) is not met on
solnix itself. NixOS's answer is stdenv: the builder and every tool on its PATH are
store paths (bootstrap-tools, then the stages), and nothing outside /nix/store is
read during a build.

## What the fix is

A solnix stdenv: builder = a store bash; PATH = store coreutils, findutils, gnugrep,
gnused, gnutar, gzip, xz, gnumake, diffutils, gawk, patch, bzip2 (all already
from-source packages here, pkgs/illumos/base-src.nix) plus the gcc wrapper
(solnix-dev's gccWrapper) and binutils from the store, and the illumos
headers/crt/libc from the gate proto (already a store path). The bootstrap is the
chain that already exists (bhost built gcc 14.3.0 and binutils 2.46.1 from source);
what changes is that every builder names store tools instead of /usr/gnu and
/usr/gcc. The illumos tools a build legitimately needs (elfdump, ldd, mcs) come from
the world's store path, not /usr/bin.

This changes every derivation's hash, so it belongs in the same planned full
rebuild as mk-src-pkg-guardfix.diff and gate-iconv-modules-gap.md, after which the
world, the kernel and every package are rebuilt by the new builders, and bhost
stops being special: any solnix system (dixi, an EC2 solnix instance) can build.
A gate check for it: build one package on dixi (no /usr/gnu) and require the build
to succeed; a negative control is the current builder, which fails there.

## Status 2026-10-11 (stream STDENV): the sha256sum + decompressor + guard-grep walls are DOWN; proven on dixi

mk-src-pkg can now build on a solnix system. Changes (one coherent set; changes
every mk-src-pkg output hash, the batched full rebuild this doc anticipated):

* **sha256sum -> /usr/bin/digest -a sha256** in mk-src-pkg.nix, mk-userland-pkg.nix,
  nix224.nix. illumos has no sha256sum; `digest -a sha256` is always present and
  emits lowercase hex, matching the plain-hex `src.sha256` (verified on dixi:
  `printf abc | /usr/bin/digest -a sha256` = ba7816bf..., and the real pkgconf
  tarball's digest == its pinned sha). A store coreutils' sha256sum would be
  circular (coreutils is itself built by mk-src-pkg), so digest is the right
  non-circular, illumos-native choice.
* **buildTools ? [ ]** arg on mk-src-pkg.nix / base-src.nix / default.nix: store
  paths whose bin/ go FIRST on the builder PATH (store gmake/gnutar/xz/gzip/
  bzip2/gnugrep/gnused + binutils' gstrip). Each is a real Nix reference, so it
  is pulled into the build-time closure (not a bare name on a PATH that may lack
  it). **Default [] is byte-identical to the old /usr/gnu/bin:/usr/bin:/usr/sbin**
  at builder runtime, so the OI buildhost path is behaviourally unchanged; a
  solnix system passes the store set. gstrip resolves from a buildTools bin/ else
  /usr/bin/gstrip, and FATALs if neither exists (illumos SVR4 /usr/bin/strip
  silently ignores --strip-debug, so it is never a fallback).
* **guard-grep fix** (mk-src-pkg-guardfix.diff folded in): the build-time-path
  guard now runs POSIX `grep -rl` with its exit status CHECKED (rc>1 => FATAL),
  not `grep -rl --binary-files=binary ... 2>/dev/null | while` which, on a system
  without GNU grep, exits 2 (illumos grep rejects --binary-files) and was read as
  "no hits" -- a blind guard.

Proof (dixi 192.168.1.124, repo subset, gate + from-source gcc from the store):
`nix build` of pkgconf-2.3.0 with buildTools=[] FAILS at the decompressor wall
(`tar: Could not stat /usr/bin/xzcat` -> `./configure: No such file`), having
already cleared the sha256 check; with buildTools set it REALIZES
(/nix/store/gyi6bh6q203vc4z0frm9k72wpxic6i1r-pkgconf-2.3.0; `pkgconf --version`
=> 2.3.0; closure gate "every ELF resolves inside /nix/store" passed).

### gcc path -- NON-ISSUE for mk-src-pkg; follow-up only on the OI-host builders

mk-src-pkg's `gcc ? "/usr/gcc/14"` default never applies on a solnix build:
base-src.nix passes the from-source gcc DERIVATION (gcc-src.nix), so
`builtins.isAttrs gcc` is true and the builder uses `$gcc/bin/gcc` from the
store (proven: pkgconf linked its libstdc++/libgcc_s via gcc.lib and passed the
closure gate on dixi). `stage0`/`/usr/gcc/14` are the host-gcc (toolchain-seed)
branch only. gcc-src.nix itself still uses the IPS `stage0 = /usr/gcc/14` seed
to COMPILE the from-source gcc -- that is the documented NixOS-style bootstrap
(bootstrap-tools seed), and the gcc binary is already a store path, so a solnix
system never re-runs it. No change needed for the core deliverable.

### Still deferred (the larger self-hosting items)

* **Default-wiring buildTools for a solnix system.** default.nix accepts
  buildTools but the shipped configs still default to []. Fully self-hosting a
  solnix system means a *seed* buildEnv (store gmake/gnutar/gzip/xz/bzip2/
  gnugrep/gnused/binutils, each referenced as a pinned storePath so there is no
  mk-src-pkg->mk-src-pkg cycle) wired as the default buildTools on-system. dixi's
  store already has every one of these (bhost-built); gzip and bzip2 were absent
  from dixi's store during this proof (only .tar.xz paths were needed) -- a seed
  must include them for the .tar.gz/.tar.bz2 packages.
* **mk-userland-pkg.nix / nix224.nix** still assume the OI host: PATH has
  /usr/gnu/bin, they `/usr/bin/curl` + `/usr/gnu/bin/tar` + `gmake` + the
  `/usr/gnu/bin/objdump` objcopy fallback, and nix224 links the host IPS libs.
  These are the OI-host userland/classic-nix path, superseded on the hermetic
  route by mk-src-pkg + nix-src.nix. Only their sha256sum was fixed here; a full
  store-tool port of them is a separate item (they need the same buildTools
  treatment, or retirement in favour of the from-source chain).

## 2026-10-29 (qbuild2): mk-src-pkg outputs are not reproducible across builds -- the random build dir is embedded

Measured: the SAME store path /nix/store/1fjqlkii...-jq-1.7.1 built twice (bhost for cache.solnix.io, and the copy in
dixi's store) has two NarHashes (served sha256:13hrx7nz..., dixi sha256:1krla6k9...), both 609208 bytes. They differ in 14
bytes of bin/jq: strings that embed the build directory, `/var/tmp/srcpkg.5qDpqy/s64/jq-1.7.1/.libs:...` (libtool's
link-time search path recorded in a string, NOT the ELF RUNPATH, which is store-only) and `CC=/var/tmp/srcpkg.5qDpqy/cc64`
(the configure line jq prints with --version). The build dir comes from mk-src-pkg.nix's `W=$(mktemp -d
/var/tmp/srcpkg.XXXXXX)`, and 10 other builders do the same (gcc-src, base-src, cli/c-*, bsdfetch, ...).

Consequence: `nix build --rebuild` of any of these fails "not deterministic", and an independent rebuild never matches the
served NarHash. So a second builder cannot ATTEST a solnix package (the trust model is reproducibility). NixOS builds in
a FIXED path (/build, via the sandbox, or NIX_BUILD_TOP) for exactly this. Fix: build in a fixed directory, e.g.
`W=$NIX_BUILD_TOP/w` (Nix gives each build a private top dir; its name is in the env, not in the output, once the build
uses a constant relative name), or `/var/tmp/srcpkg` + the drv hash. This moves every mk-src-pkg out, so it belongs in the
batched rebuild above.

## 2026-10-29 (fodfix): what a fresh solnix host hits building its own toplevel

Measured on the relaunched dixi (54.80.68.157, DP fix AMI, no /usr/gnu, no /usr/gcc), building nix-config 1e133df's
`solnixConfigurations.dixi` toplevel against solnix 0eb4e89 + the fetch-tarball fix, with no imported store paths.

1. **fetch-tarball.nix (FIXED here).** Its builder ran host `tar -xzf`. On a solnix host that is illumos tar, which
   execs `/usr/bin/gzcat`, finds none, prints `tar: blocksize = 0` and EXITS 0 with nothing extracted, so the FOD came
   out as an empty directory (NAR `sha256-pQpattmS...`, 96 bytes) and failed the hash check. The single-top-level guard
   was blind for the same reason: an empty `tar -t` list counts as one line. Fixed by unpacking with Nix's own
   `builtin:unpack-channel` and copying `tree/` up with `/usr/bin/cp -RP`. Out paths are unchanged (FOD = name +
   hash); only the four FODs' .drv files move. Verified on dixi for the proto (0f0jr9xl), kernel-nd's src (1yhpjbxj),
   nvidia-oss's rmSrc (19r6wrm4) and hmSrc (08l22vv6), each built under a new name. Negative control: the old builder
   on dixi gives pQpattmS.
2. **gcc-14.3.0 (gcc-src.nix): the next wall, and the root of everything left.** `PATH=/usr/gnu/bin:...`,
   `stage0=/usr/gcc/14`, `/usr/bin/gas`, `/usr/bin/gstrip`, `/usr/gnu/bin/objdump`, and `tar xf` of a .tar.xz (fails:
   `tar: Could not stat /usr/bin/xzcat`). The main output 6jxijj8h is not on cache.solnix.io (it fails the publish gate,
   docs/pending/world-unresolved-needed.md), so a fresh host must build it and can't.
3. **Behind gcc, all OI-host (buildTools=[]):** seedSrcPkgs' zlib, libxml2, nspr, nss, the seed world
   (illumos-userland hnj340g3, not the served awwznprc), gnutar, gzip, gnused, gnugrep -> solnix-seed-build-tools ->
   cmake, boost -> libtorrent-rasterbar -> solnix-torrent -> its SMF manifests; and gcc-wrapper -> solnix-dev-full.
   Host paths named: /usr/gnu/bin, /usr/gcc/14, /usr/bin/gstrip, /usr/include (libtorrent also /usr/local). None of these
   23 outputs is on cache.solnix.io.
4. The ~16 writer drvs (solnix-etc*, channel-*, solnix-version*) list /usr/gnu/bin on PATH but use only bash builtins,
   and they BUILT.

So "any solnix host builds its own toplevel" needs either the seed chain served (gcc main output, the seed tools and
their closure, after gcc passes the publish gate) or the stdenv work above. Fixing more FODs won't get there.
Other FOD builders with the same host-tar pattern, which a fresh host will hit only if it builds them: cargo.nix
`vendorOf` and graphics/cosmic.nix (`tar xzf` + PATH=/usr/gnu/bin), i915-driver.nix's obsdDrm (PATH /usr/gnu/bin).
