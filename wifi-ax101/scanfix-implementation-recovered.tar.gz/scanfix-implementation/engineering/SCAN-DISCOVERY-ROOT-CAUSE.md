# AX101 scan discovery — RUN106 source root-cause and scan-fix candidate

## Scope and immutable inputs

- Repository: `Cadiocto/WhateverXe-MiniBook-X-N150`
- Validation branch at investigation start: `ax101-r5-integration-validation`
- Validation HEAD at investigation start: `c70455cdbdbfcf59baac087decb9ece519cf5700`
- Production branch at investigation start: `wifi-ax101-openindiana` (not modified)
- Pinned Solnix: `1cee7021091f3df92b7816ece2902ff59b37f1be`
- Pinned illumos-gate: `098e95820891f8a83fae679daece7fcf58b7b3a4`
- Target laptop kernel: `illumos-c893fd03ad` (OpenIndiana Hipster 2026.10, 2026-10-30 image)
- Adapter identity: PCI `8086:54F0`, subsystem `8086:0244`, firmware API `77`, configuration `iwx_cfg_so_a0_hr_b0`.

The RUN106 guest's exact generated C source was retained as `run87-if_iwx_illumos.c`, SHA-256:

`c59a26b82766e49fbc12f78e4a89eabfce85c8b70be9c055fdffe258027fc180`

The scan fix was developed against that generated source, not against an untouched upstream file. The additive patch is `patches/0028-ax101-scan-notification-rx-fix.patch` (SHA-256 `9d469589bc5397efa89199a5c2fa86654a62956ab6ff4e0c33807e52b8e91f80`).

## What the physical evidence establishes — and what it does not

The supplied `ax101-full-diagnostic-20261127-214507.log` records:

- `dladm scan-wifi` / GLDv3 `WL_SCAN` returns success (`rc=0`);
- firmware command completion is received (`FIRMWARE_COMMAND_DONE`, `FIRMWARE_COMMAND_RETURN rc=0`);
- UMAC scan-v14 command returns `rc=0`;
- MSI/interrupt and RX notification paths are entered;
- `iwx_init_task` runs before the scan wrapper returns;
- repeated scans take about 0.26 seconds and `dladm show-wifi` still reports `disconnected` with ESSID `--`;
- interface RX/TX MAC counters remain zero.

The log does **not** record the numeric RX opcode, group, raw/normalized qid, index, scan-complete notification, or the reason that queued `iwx_init_task`. Its `IWX_RFKILL_CHECK` marker alone does not establish that RFKill is asserted. Therefore the old capture cannot distinguish “firmware did not send scan-complete/beacons” from “firmware sent them but the driver misparsed or discarded them.”

## Confirmed defects in the RUN106-compiled source

### 1. Firmware-originated RX qid was masked too late

`struct iwx_cmd_header.qid` carries an unsolicited/firmware-originated marker in bit `0x80`. The previous `iwx_rx_pkt_valid()` masked that bit only in a local variable; `iwx_rx_pkt()` continued using the raw qid when looking up `sc->txq[qid]` and a TX descriptor. A firmware notification with bit `0x80` could therefore index the TX queue out of range or consult a command descriptor that does not belong to an unsolicited notification.

The fix normalizes qid once, records raw and normalized values, rejects impossible host queue IDs before dispatch, and confines wide-to-narrow command-ID conversion to a non-unsolicited host command response on the DQA command queue. A second guard in the command-response switch explicitly rejects unsolicited packets before any access to `sc->txq[IWX_DQA_CMD_QUEUE].data[idx]`.

The RX descriptor's `idx` is `uint8_t`, and the TX ring has 256 entries. Thus every possible descriptor index 0..255 is representable and in range. The patch records that invariant with a compile-time assertion. The compressed-BA notification carries a wider 16-bit TFD index, so that separate index is range-checked before accessing `ring->data[]`.

### 2. Scan-iteration completion was treated as whole-scan completion

The previous switch handled `IWX_SCAN_ITERATION_COMPLETE_UMAC` and `IWX_SCAN_COMPLETE_UMAC` as equivalent and called `iwx_endscan()` for both. They are distinct notifications: iteration-complete reports progress/results for one iteration; scan-complete ends the entire request. The patched handler validates iteration payload length and reports progress, but only `IWX_SCAN_COMPLETE_UMAC` calls `iwx_endscan()`.

### 3. Scan state was published after the synchronous firmware ACK wait

The previous `iwx_scan()` called `iwx_initiate_scan()` before setting `IWX_FLAG_SCANNING` and `ic_state = IEEE80211_S_SCAN`. The command submission waits for its firmware response; RX interrupt handling can run during that wait. If completion is handled before those fields are set, `iwx_endscan()` sees no active scan and returns, losing the completion. The fix publishes scan state and a generation before command submission, and rolls the state back on submission error only when the same generation remains active.

## Recovery/reinitialization observability

The old physical capture shows `iwx_init_task` execution but does not tell which caller scheduled it. The patch adds fixed reason codes and a DTrace probe at all 14 `iwx_schedule_init_task()` call sites (command timeout, bgscan task, newstate, watchdog, CT kill, channel switch, RX error, MSI and MSIX RF-kill/SW/HW error/fatal paths). It also records flags, driver generation, ifnet flags, net80211 state, task-add result and scan generation. RFKill register/result is a separate probe. No RFKill cause is asserted without this new evidence.

## RX, BSS and GLDv3 visibility

The diagnostic probes record RX header fields and payload length, packet-validation result, rejection reason, normalized opcode, scan-complete and iteration notifications, valid MPDUs, beacon/probe-response MPDUs, net80211 BSS-node create/update events, `ic_scan_count`, BSS tree count, GLDv3 `WL_SCAN` result and ESS-list snapshot count. The existing GLDv3 ESS snapshot semantics are not changed: the current evidence does not justify treating ESS-list publication as the primary fault.

## Regression coverage

`tests/scan-regression.py` runs 25 deterministic protocol/state/property scenarios plus 10 source-mutant negative controls (35 unittest cases total). It does not use sleeps or random interleavings. It covers qid normalization and bounds, unsolicited command-descriptor exclusion, wide/narrow conversion, scan completion versus iteration progress, malformed lengths, scan state publication before command submit, duplicate/late notifications, reinitialization/RFKill/HW_ERR instrumentation, empty/single/multiple BSS models, ESS snapshot lifetime, repeat scan, RX/DMA and GLDv3 property contracts.

The exact patch round-trip was tested with `patch --fuzz=0`: reverse the patch on a copy, dry-run/apply it forward, then compare all five touched production files byte-for-byte with the candidate.

## Acceptance boundary

Source/model tests do not prove that the physical AX101 now discovers access points. The new native target-kernel build must compile/link the modified source. The consolidated on-device test is `tests/run-ax101-scan-validation.sh`; it runs DTrace concurrently with one `dladm scan-wifi` and saves before/after interface, kstat and dmesg state. A scan is accepted only when actual ESS entries appear in `dladm show-wifi` and their BSS/RX notification path is visible.

Association, WPA2 handshake, DHCP, DNS and Internet traffic remain separate acceptance gates and are not claimed by this scan fix.
