#!/bin/bash
# One consolidated physical scan test for the new scan-notification build.
set -u

OUT=${1:-/var/tmp/ax101-scan-validation-$(date +%Y%m%d-%H%M%S)}
ROOT=$(cd -- "$(dirname -- "$0")/.." && pwd)
DTRACE_SCRIPT="$ROOT/diagnostics/ax101-scan.d"
mkdir -p "$OUT"

fail() { echo "FAIL: $*" | tee -a "$OUT/result.txt" >&2; exit 1; }
run_capture() {
    label=$1; shift
    echo "=== $label ===" | tee -a "$OUT/result.txt"
    "$@" >"$OUT/$label.log" 2>&1
    rc=$?
    echo "$label exit_code=$rc" | tee -a "$OUT/result.txt"
    return 0
}

[ "$(uname -v)" = "illumos-c893fd03ad" ] || fail "wrong kernel: $(uname -v)"
[ -c /dev/iwx0 ] || [ -e /dev/iwx0 ] || fail "/dev/iwx0 is missing"
command -v dtrace >/dev/null 2>&1 || fail "dtrace is not installed"
command -v dladm >/dev/null 2>&1 || fail "dladm is not installed"

{
    echo "TARGET_KERNEL=$(uname -v)"
    echo "DATE=$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    echo "FIRMWARE_API=77"
    echo "PCI_IDENTITY_EXPECTED=8086:54F0/8086:0244"
    echo "INTERFACE=iwx0"
} > "$OUT/identity.txt"

run_capture before-ifconfig /sbin/ifconfig -a
run_capture before-wifi /usr/sbin/dladm show-wifi
run_capture before-kstat /usr/bin/kstat -p
run_capture before-dmesg /usr/bin/dmesg

# DTrace -c synchronises tracing with the exact scan command; no sleep-based
# race between attaching probes and issuing the scan.
set +e
dtrace -q -s "$DTRACE_SCRIPT" -c "/usr/sbin/dladm scan-wifi" >"$OUT/scan-dtrace.log" 2>&1
dtrace_rc=$?
set -e
echo "dtrace_scan_exit=$dtrace_rc" | tee -a "$OUT/result.txt"
[ "$dtrace_rc" -eq 0 ] || fail "DTrace/scan command returned non-zero"

run_capture after-scan-wifi /usr/sbin/dladm show-wifi
run_capture after-ifconfig /sbin/ifconfig -a
run_capture after-kstat /usr/bin/kstat -p
run_capture after-dmesg /usr/bin/dmesg

# Keep the complete raw output. An ESS is counted only when a non-header row
# contains a non-empty, non-placeholder ESSID; human review remains required.
awk '
    NR == 1 {
        for (i = 1; i <= NF; i++)
            if ($i == "ESSID") essid_col = i
        next
    }
    essid_col && NF >= essid_col && $essid_col != "--" &&
        $essid_col != "-" && $essid_col != "" { n++ }
    END {
        if (!essid_col) {
            print "SCAN_ROWS_WITH_ESSID=UNPARSED_HEADER"
            exit 2
        }
        print "SCAN_ROWS_WITH_ESSID=" (n + 0)
    }
' "$OUT/after-scan-wifi.log" | tee -a "$OUT/result.txt" ||
    fail "could not parse ESSID column in dladm show-wifi output"

echo "PHYSICAL_ASSOCIATION=NOT_TESTED" | tee -a "$OUT/result.txt"
echo "DHCP_DNS_INTERNET=NOT_TESTED" | tee -a "$OUT/result.txt"
echo "SCAN_EVIDENCE_DIR=$OUT" | tee -a "$OUT/result.txt"
echo "SCAN_VALIDATION_CAPTURE=COMPLETE" | tee -a "$OUT/result.txt"
