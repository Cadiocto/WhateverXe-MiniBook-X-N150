#!/usr/bin/env python3
"""Deterministic AX101 RX/scan-state/ESS-list regression suite.

This is a host-side protocol/state model plus structural assertions against the
production C sources.  It deliberately avoids random timing and sleep-based
synchronisation.  Native target compilation and physical RF discovery remain
separate acceptance gates.
"""
from __future__ import annotations

import re
import unittest
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
# In the normal repository this script is copied to wifi-ax101/tests and the
# source tree is passed explicitly by the native-build workflow.
DEFAULT_SOURCE = Path("/tmp/solnix-wifi/src/ports/wifi")


def source_root() -> Path:
    import os
    return Path(os.environ.get("AX101_SOURCE_ROOT", str(DEFAULT_SOURCE)))


def body(text: str, symbol: str) -> str:
    """Return a C function body by matching its opening brace and balancing."""
    matches = list(re.finditer(r"\b" + re.escape(symbol) + r"\s*\([^;]*?\)\s*\{", text, re.S))
    if not matches:
        raise AssertionError(f"function not found: {symbol}")
    start = matches[-1].end() - 1
    depth = 0
    in_string = False
    in_char = False
    escape = False
    line_comment = False
    block_comment = False
    i = start
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if line_comment:
            if ch == "\n":
                line_comment = False
        elif block_comment:
            if ch == "*" and nxt == "/":
                block_comment = False
                i += 1
        elif in_string:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == '"':
                in_string = False
        elif in_char:
            if escape:
                escape = False
            elif ch == "\\":
                escape = True
            elif ch == "'":
                in_char = False
        elif ch == "/" and nxt == "/":
            line_comment = True
            i += 1
        elif ch == "/" and nxt == "*":
            block_comment = True
            i += 1
        elif ch == '"':
            in_string = True
        elif ch == "'":
            in_char = True
        elif ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start + 1:i]
        i += 1
    raise AssertionError(f"unbalanced C function: {symbol}")


@dataclass
class ScanState:
    scanning: bool = False
    bgscan: bool = False
    running: bool = True
    ic_state: str = "INIT"
    scan_count: int = 0
    generation: int = 0
    end_calls: int = 0
    init_reasons: list[str] = field(default_factory=list)
    bss: dict[str, dict] = field(default_factory=dict)
    ess_snapshot: list[str] = field(default_factory=list)
    tx_ring_touches: int = 0
    rx_ring_owner: str = "DEVICE"
    dma_syncs: list[str] = field(default_factory=list)
    lock_depth: int = 0
    property_reads: int = 0

    def publish_scan(self) -> int:
        self.generation += 1
        self.scanning = True
        self.ic_state = "SCAN"
        return self.generation

    def end_scan(self) -> bool:
        if not (self.scanning or self.bgscan):
            return False
        self.scanning = False
        self.bgscan = False
        self.ic_state = "SCAN_DONE"
        self.scan_count += 1
        self.end_calls += 1
        return True

    def stop(self) -> None:
        self.generation += 1
        self.scanning = False
        self.bgscan = False
        self.running = False
        self.ic_state = "INIT"

    def submit(self, callback=None, rc: int = 0) -> None:
        generation = self.publish_scan()
        if callback is not None:
            callback()
        if rc != 0 and generation == self.generation and self.scanning:
            self.scanning = False
            self.ic_state = "INIT"

    def recovery(self, reason: str, *, rfkill: bool = False, hwerr: bool = False) -> None:
        self.init_reasons.append(reason)
        if rfkill:
            self.init_reasons.append("RFKILL_STATE=ASSERTED")
        if hwerr:
            self.init_reasons.append("HW_ERR=ASSERTED")
        self.stop()

    def add_bss(self, bssid: str, ssid: str, rssi: int) -> None:
        old = self.bss.get(bssid)
        self.bss[bssid] = {"ssid": ssid, "rssi": rssi, "new": old is None}

    def snapshot(self) -> None:
        self.ess_snapshot = [v["ssid"] for v in self.bss.values() if v["ssid"]]

    def ess_list(self) -> list[str]:
        self.property_reads += 1
        return list(self.ess_snapshot)


class RxResult:
    def __init__(self, accepted=False, qid=None, code=None, ended=False,
                 error=None, tx_ring_touch=False, progress=False):
        self.accepted = accepted
        self.qid = qid
        self.code = code
        self.ended = ended
        self.error = error
        self.tx_ring_touch = tx_ring_touch
        self.progress = progress


def parse_rx(state: ScanState, *, raw_qid: int, idx: int, group: int,
             opcode: int, payload_len: int, uid: int = 0,
             scanned_channels: int = 0, cmd_narrow=False,
             known=True) -> RxResult:
    """Small deterministic model of the corrected RX dispatch contract."""
    min_header = 8
    if payload_len < min_header:
        return RxResult(error="malformed-length")
    unsolicited = bool(raw_qid & 0x80)
    qid = raw_qid & 0x7f
    code = (group << 8) | opcode
    touched = False
    # Normalize the firmware flag first, then validate the queue field for
    # every packet before any dispatch can mutate scan state or index txq[].
    if qid >= 10:
        return RxResult(error="bad-qid", qid=qid, code=code)
    # Only host command replies from DQA may consult a descriptor. The wire
    # index is uint8_t and the command ring has 256 entries (compile-time gate).
    if not unsolicited and qid == 0 and group == 1:
        touched = True
        if cmd_narrow:
            code = opcode
    if not known:
        return RxResult(accepted=True, qid=qid, code=code,
                        tx_ring_touch=touched)
    ended = False
    progress = False
    if group == 0 and opcode == 0x0f:
        if payload_len < 16:
            return RxResult(error="malformed-scan-complete", qid=qid, code=code)
        if uid == 0:
            ended = state.end_scan()
    elif group == 0 and opcode == 0xb5:
        # 16-byte header + 8 bytes per scanned channel result in this API.
        if payload_len < 16 + scanned_channels * 8:
            return RxResult(error="malformed-iteration", qid=qid, code=code)
        progress = True
    return RxResult(accepted=True, qid=qid, code=code, ended=ended,
                    tx_ring_touch=touched, progress=progress)


def validate_ba_tfd(qid: int, idx: int, nqueues: int = 10,
                    ring_count: int = 256) -> bool:
    """BA TFD index is uint16_t, unlike the RX descriptor's uint8_t index."""
    return 0 <= qid < nqueues and 0 <= idx < ring_count


def check_rx_contract(rx: str, tx: str, ba: str, c: str) -> None:
    assert "qid = raw_qid & ~IWX_RX_QID_UNSOLICITED;" in rx
    assert "if (qid >= IWX_NUM_TX_QUEUES)" in rx
    assert rx.index("if (qid >= IWX_NUM_TX_QUEUES)") < rx.index("switch (code)")
    assert "if (!unsolicited && qid == IWX_DQA_CMD_QUEUE" in rx
    assert rx.index("if (!unsolicited && qid == IWX_DQA_CMD_QUEUE") < rx.index("ring = &sc->txq[qid]")
    start = rx.index("case IWX_WIDE_ID(IWX_DATA_PATH_GROUP")
    end = rx.index("case IWX_INIT_COMPLETE_NOTIF", start)
    command_response = rx[start:end]
    assert "if (unsolicited || qid != IWX_DQA_CMD_QUEUE" in command_response
    assert command_response.index("if (unsolicited || qid != IWX_DQA_CMD_QUEUE") < command_response.index("sc->txq[IWX_DQA_CMD_QUEUE].data[idx]")
    assert "typedef char iwx_rx_index_ring_size_must_be_256" in c
    assert "idx >= IWX_TX_RING_COUNT" not in rx
    assert "int qid = cmd_hdr->qid & ~IWX_RX_QID_UNSOLICITED" in tx
    assert "if (qid >= IWX_NUM_TX_QUEUES)" in tx
    assert tx.index("if (qid >= IWX_NUM_TX_QUEUES)") < tx.index("ring = &sc->txq[qid]")
    assert "qid < 0 || qid >= IWX_NUM_TX_QUEUES" in ba
    assert "idx >= IWX_TX_RING_COUNT" in ba
    assert ba.index("idx >= IWX_TX_RING_COUNT") < ba.index("ring = &sc->txq[qid]")


def check_scan_contract(c: str, scan: str) -> None:
    assert "sc->sc_flags |= IWX_FLAG_SCANNING" in scan
    assert "iwx_initiate_scan(sc, 0)" in scan
    assert scan.index("sc->sc_flags |= IWX_FLAG_SCANNING") < scan.index("iwx_initiate_scan(sc, 0)")
    assert scan.index("ic->ic_state = IEEE80211_S_SCAN") < scan.index("iwx_initiate_scan(sc, 0)")
    start = c.index("case IWX_SCAN_ITERATION_COMPLETE_UMAC")
    end = c.index("case IWX_MCC_CHUB_UPDATE_CMD", start)
    iteration = c[start:end]
    assert "iwx_endscan(sc)" not in iteration
    start = c.index("case IWX_SCAN_COMPLETE_UMAC")
    end = c.index("case IWX_SCAN_ITERATION_COMPLETE_UMAC", start)
    complete = c[start:end]
    assert "if (uid == 0)" in complete and "iwx_endscan(sc)" in complete


def check_unknown_contract(rx: str) -> None:
    start = rx.index("default:")
    default = rx[start:]
    assert "iwx_rx_packet_unknown" in default
    assert "handled = 0;" in default
    assert "iwx_endscan(sc)" not in default


def check_init_reason_contract(c: str) -> None:
    assert len(re.findall(r"iwx_schedule_init_task\(sc, IWX_INIT_REASON_", c)) == 14
    assert "DTRACE_PROBE7(iwx_init_task_schedule" in c
    assert "DTRACE_PROBE6(iwx_init_task_enter" in c
    assert "DTRACE_PROBE4(iwx_init_task_exit" in c


class ScanRegression(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        root = source_root()
        cls.c = (root / "iwx/build/if_iwx_illumos.c").read_text()
        cls.var = (root / "iwx/build/dev/pci/if_iwxvar.h").read_text()
        cls.glue = (root / "iwx/iwx_glue.c").read_text()
        cls.gld = (root / "iwm/iwm_gld.c").read_text()
        cls.input = (root / "net80211/build/ieee80211_input.c").read_text()
        cls.rx = body(cls.c, "iwx_rx_pkt")
        cls.scan = body(cls.c, "iwx_scan")
        cls.bgscan = body(cls.c, "iwx_bgscan")
        cls.tx = body(cls.c, "iwx_rx_tx_cmd")
        cls.ba = body(cls.c, "iwx_rx_compressed_ba")
        cls.valid = body(cls.c, "iwx_rx_pkt_valid")
        cls.endscan = body(cls.c, "iwx_endscan")
        cls.gld_prop = cls.gld[cls.gld.find("case MAC_PROP_WL_ESS_LIST:"):]

    # 1-10: packet format, IDs and race handling.
    def test_01_valid_scan_complete(self):
        s = ScanState(scanning=True, ic_state="SCAN")
        r = parse_rx(s, raw_qid=0x80, idx=0, group=0, opcode=0x0f,
                     payload_len=16, uid=0)
        self.assertTrue(r.accepted and r.ended)
        self.assertEqual(s.end_calls, 1)

    def test_02_iteration_complete_is_progress_only(self):
        s = ScanState(scanning=True, ic_state="SCAN")
        r = parse_rx(s, raw_qid=0x80, idx=0, group=0, opcode=0xb5,
                     payload_len=32, scanned_channels=2)
        self.assertTrue(r.accepted and r.progress)
        self.assertEqual(s.end_calls, 0)
        self.assertTrue(s.scanning)

    def test_03_unsolicited_qid_bit_is_normalized(self):
        check_rx_contract(self.rx, self.tx, self.ba, self.c)
        s = ScanState(scanning=True)
        r = parse_rx(s, raw_qid=0x80, idx=0, group=0, opcode=0x0f,
                     payload_len=16)
        self.assertEqual(r.qid, 0)
        self.assertFalse(r.tx_ring_touch)
        self.assertIn("qid = raw_qid & ~IWX_RX_QID_UNSOLICITED", self.rx)

    def test_04_invalid_qid_never_indexes_txq(self):
        r = parse_rx(ScanState(), raw_qid=0x7f, idx=0, group=0, opcode=0x0f,
                     payload_len=16)
        self.assertEqual(r.error, "bad-qid")
        self.assertLess(self.rx.index("if (qid >= IWX_NUM_TX_QUEUES)"),
                        self.rx.index("switch (code)"))

    def test_05_invalid_idx_is_rejected_before_ring_data(self):
        self.assertIn("uint16_t i, tfd_cnt, ra_tid_cnt, idx;", self.ba)
        self.assertIn("idx >= IWX_TX_RING_COUNT", self.ba)
        self.assertLess(self.ba.index("idx >= IWX_TX_RING_COUNT"),
                        self.ba.index("ring = &sc->txq[qid]"))
        self.assertTrue(validate_ba_tfd(2, 255))
        self.assertFalse(validate_ba_tfd(2, 256))

    def test_06_unknown_opcode_does_not_end_scan(self):
        s = ScanState(scanning=True)
        parse_rx(s, raw_qid=0x80, idx=0, group=0, opcode=0xfe,
                 payload_len=16, known=False)
        self.assertEqual(s.end_calls, 0)
        self.assertIn("iwx_rx_packet_unknown", self.rx)

    def test_07_wrong_group_does_not_end_scan(self):
        s = ScanState(scanning=True)
        parse_rx(s, raw_qid=0x80, idx=0, group=2, opcode=0x0f,
                 payload_len=16)
        self.assertEqual(s.end_calls, 0)

    def test_08_malformed_notification_length_rejected(self):
        r = parse_rx(ScanState(scanning=True), raw_qid=0x80, idx=0,
                     group=0, opcode=0x0f, payload_len=7)
        self.assertEqual(r.error, "malformed-length")
        self.assertIn("iwx_scan_complete_malformed", self.c)

    def test_09_wide_narrow_conversion_is_command_ring_only(self):
        s = ScanState()
        host = parse_rx(s, raw_qid=0, idx=4, group=1, opcode=0x12,
                        payload_len=16, cmd_narrow=True)
        fw = parse_rx(s, raw_qid=0x80, idx=4, group=1, opcode=0x12,
                      payload_len=16, cmd_narrow=True)
        self.assertEqual(host.code, 0x12)
        self.assertEqual(fw.code, 0x112)
        self.assertTrue(host.tx_ring_touch)
        self.assertFalse(fw.tx_ring_touch)

    def test_10_scan_state_is_published_before_command(self):
        check_scan_contract(self.c, self.scan)
        state_write = self.scan.index("sc->sc_flags |= IWX_FLAG_SCANNING")
        state_set = self.scan.index("ic->ic_state = IEEE80211_S_SCAN")
        command = self.scan.index("iwx_initiate_scan(sc, 0)")
        self.assertLess(state_write, command)
        self.assertLess(state_set, command)
        s = ScanState()
        immediate = lambda: parse_rx(s, raw_qid=0x80, idx=0, group=0,
                                     opcode=0x0f, payload_len=16)
        s.submit(callback=immediate)
        self.assertEqual(s.end_calls, 1)
        self.assertFalse(s.scanning)

    # 11-18: scan state machine, recovery and BSS population.
    def test_11_duplicate_scan_complete_is_idempotent(self):
        s = ScanState(scanning=True)
        r1 = parse_rx(s, raw_qid=0x80, idx=0, group=0, opcode=0x0f,
                      payload_len=16)
        r2 = parse_rx(s, raw_qid=0x80, idx=0, group=0, opcode=0x0f,
                      payload_len=16)
        self.assertTrue(r1.ended)
        self.assertFalse(r2.ended)
        self.assertEqual(s.end_calls, 1)
        self.assertIn("iwx_scan_end_ignored", self.endscan)

    def test_12_notification_after_interface_stop_is_ignored(self):
        s = ScanState(scanning=True)
        s.stop()
        r = parse_rx(s, raw_qid=0x80, idx=0, group=0, opcode=0x0f,
                     payload_len=16)
        self.assertFalse(r.ended)
        self.assertEqual(s.end_calls, 0)

    def test_13_reinitialization_during_scan_has_reason_and_state_trace(self):
        s = ScanState(scanning=True)
        s.recovery("WATCHDOG")
        self.assertIn("WATCHDOG", s.init_reasons)
        self.assertFalse(s.running)
        self.assertIn("iwx_init_task_schedule", self.c)
        self.assertIn("iwx_init_task_enter", self.c)
        self.assertIn("iwx_init_task_exit", self.c)

    def test_14_rfkill_during_scan_is_distinguished_from_other_recovery(self):
        s = ScanState(scanning=True)
        s.recovery("MSI_RF_KILL", rfkill=True)
        self.assertIn("RFKILL_STATE=ASSERTED", s.init_reasons)
        self.assertIn("iwx_rfkill_state", self.c)
        self.assertIn("IWX_INIT_REASON_MSI_RF_KILL", self.c)

    def test_15_hw_error_recovery_during_scan_is_distinguished(self):
        s = ScanState(scanning=True)
        s.recovery("MSI_HW_ERROR", hwerr=True)
        self.assertIn("HW_ERR=ASSERTED", s.init_reasons)
        self.assertIn("IWX_INIT_REASON_MSI_HW_ERROR", self.c)

    def test_16_empty_scan_result_is_valid(self):
        s = ScanState(scanning=True)
        s.end_scan()
        s.snapshot()
        self.assertEqual(s.ess_list(), [])

    def test_17_single_bss_is_discovered_and_snapshotted(self):
        s = ScanState(scanning=True)
        s.add_bss("00:11:22:33:44:55", "one-ap", -43)
        s.end_scan()
        s.snapshot()
        self.assertEqual(s.ess_list(), ["one-ap"])

    def test_18_multiple_bss_nodes_are_discovered_and_updated(self):
        s = ScanState(scanning=True)
        s.add_bss("00:11:22:33:44:55", "one-ap", -43)
        s.add_bss("00:11:22:33:44:66", "two-ap", -60)
        s.add_bss("00:11:22:33:44:55", "one-ap", -39)
        self.assertEqual(len(s.bss), 2)
        self.assertEqual(s.bss["00:11:22:33:44:55"]["rssi"], -39)
        self.assertIn("ieee80211_bss_node_update", self.input)

    # 19-25: ESS snapshot, second scan, ring/DMA/lock invariants.
    def test_19_scan_snapshot_contains_all_bss_results(self):
        s = ScanState()
        s.add_bss("a", "ap-a", -40)
        s.add_bss("b", "ap-b", -50)
        s.snapshot()
        self.assertEqual(s.ess_list(), ["ap-a", "ap-b"])
        self.assertIn("iwm_gld_ess_list_snapshot", self.gld_prop)

    def test_20_ess_list_remains_readable_after_radio_stop(self):
        s = ScanState()
        s.add_bss("a", "ap-a", -40)
        s.snapshot()
        s.stop()
        self.assertEqual(s.ess_list(), ["ap-a"])

    def test_21_second_scan_can_start_after_first_completion(self):
        s = ScanState()
        s.submit()
        self.assertTrue(s.end_scan())
        s.submit()
        self.assertTrue(s.scanning)
        self.assertEqual(s.generation, 2)

    def test_22_malformed_rx_does_not_mutate_rx_ring_state(self):
        s = ScanState()
        before = s.rx_ring_owner
        parse_rx(s, raw_qid=0x80, idx=0, group=0, opcode=0x0f,
                 payload_len=2)
        self.assertEqual(s.rx_ring_owner, before)

    def test_23_dma_ownership_protocol_is_retained_in_rx_path(self):
        self.assertIn("BUS_DMASYNC_POSTREAD", self.c)
        self.assertIn("m_hold", self.c)
        self.assertIn("iwx_rx_addbuf", self.rx)
        s = ScanState()
        s.rx_ring_owner = "DEVICE"
        s.dma_syncs.extend(["POSTREAD", "PREREAD"])
        self.assertEqual(s.dma_syncs, ["POSTREAD", "PREREAD"])

    def test_24_scan_observability_and_existing_lock_contract_are_preserved(self):
        self.assertIn("iwx_rx_mpdu_valid", self.c)
        self.assertIn("iwx_rx_beacon_or_probe_response", self.c)
        self.assertIn("iwx_bss_tree_snapshot", self.glue)
        self.assertIn("iwx_il_scan_enter", self.glue)
        self.assertIn("n80211_giant_enter", self.gld)
        self.assertIn("n80211_giant_exit", self.gld)
        self.assertIn("mac_pdata_update", self.gld)
        self.assertIn("mac_tx_update", self.gld)

    def test_25_glDv3_property_reads_published_ess_snapshot(self):
        self.assertIn("iwm_fill_esslist(g->g_scan, cnt, val, sz)", self.gld_prop)
        self.assertIn("g->g_nscan", self.gld_prop)
        self.assertIn("DTRACE_PROBE4(iwm_gld_ess_list_snapshot", self.gld_prop)


class NegativeControls(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        root = source_root()
        cls.c = (root / "iwx/build/if_iwx_illumos.c").read_text()
        cls.rx = body(cls.c, "iwx_rx_pkt")
        cls.scan = body(cls.c, "iwx_scan")
        cls.tx = body(cls.c, "iwx_rx_tx_cmd")
        cls.ba = body(cls.c, "iwx_rx_compressed_ba")

    def test_nc01_raw_qid_mutant_is_caught(self):
        mutant = self.rx.replace("qid = raw_qid & ~IWX_RX_QID_UNSOLICITED;", "qid = raw_qid;", 1)
        with self.assertRaises(AssertionError):
            check_rx_contract(mutant, self.tx, self.ba, self.c)

    def test_nc02_iteration_endscan_mutant_is_caught(self):
        start = self.c.index("case IWX_SCAN_ITERATION_COMPLETE_UMAC")
        end = self.c.index("case IWX_MCC_CHUB_UPDATE_CMD", start)
        mutant_c = self.c[:start] + self.c[start:end].replace(
            "/* Progress only:", "iwx_endscan(sc);\n\t\t\t/* Progress only:", 1) + self.c[end:]
        with self.assertRaises(AssertionError):
            check_scan_contract(mutant_c, self.scan)

    def test_nc03_late_scan_publish_mutant_is_caught(self):
        mutant = self.scan.replace("sc->sc_flags |= IWX_FLAG_SCANNING;", "/* moved later */", 1)
        with self.assertRaises(AssertionError):
            check_scan_contract(self.c, mutant)

    def test_nc04_unbounded_idx_mutant_is_caught(self):
        mutant = self.ba.replace("idx >= IWX_TX_RING_COUNT", "idx < 0", 1)
        with self.assertRaises(AssertionError):
            check_rx_contract(self.rx, self.tx, mutant, self.c)

    def test_nc05_unbounded_tx_qid_mutant_is_caught(self):
        mutant = self.tx.replace("if (qid >= IWX_NUM_TX_QUEUES) {", "if (0) {", 1)
        with self.assertRaises(AssertionError):
            check_rx_contract(self.rx, mutant, self.ba, self.c)

    def test_nc06_wrong_uid_mutant_is_caught(self):
        mutant = self.c.replace("if (uid == 0)", "if (uid != 0)", 1)
        with self.assertRaises(AssertionError):
            check_scan_contract(mutant, self.scan)

    def test_nc07_unknown_packet_becoming_scan_complete_is_caught(self):
        start = self.rx.index("default:")
        mutant_rx = self.rx[:start] + self.rx[start:].replace(
            "handled = 0;", "iwx_endscan(sc);\n\t\t\thandled = 0;", 1)
        with self.assertRaises(AssertionError):
            check_unknown_contract(mutant_rx)

    def test_nc08_init_task_without_reason_probe_is_caught(self):
        mutant = self.c.replace("DTRACE_PROBE7(iwx_init_task_schedule,", "/* missing reason probe */", 1)
        with self.assertRaises(AssertionError):
            check_init_reason_contract(mutant)

    def test_nc09_unsolicited_ack_cannot_touch_command_descriptor(self):
        mutant = self.rx.replace("if (unsolicited || qid != IWX_DQA_CMD_QUEUE)",
                                 "if (qid != IWX_DQA_CMD_QUEUE)", 1)
        with self.assertRaises(AssertionError):
            check_rx_contract(mutant, self.tx, self.ba, self.c)

    def test_nc10_unbounded_rx_qid_is_caught(self):
        mutant = self.rx.replace("if (qid >= IWX_NUM_TX_QUEUES) {", "if (0) {", 1)
        with self.assertRaises(AssertionError):
            check_rx_contract(mutant, self.tx, self.ba, self.c)


if __name__ == "__main__":
    unittest.main(verbosity=2)
