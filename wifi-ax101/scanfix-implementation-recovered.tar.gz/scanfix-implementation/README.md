# AX101 scan-discovery source candidate

This is a source-only implementation package for the AX101 scan-discovery fix. It is not a driver binary and is not a claim that physical Wi-Fi discovery is already working.

## Exact base and patch order

The patch is additive to the actual RUN106 generated OpenIndiana source after the pinned R5 patch stack, RUN87 adaptation and `iwx/gen-illumos-src.sh` generator replay. Apply it from the Solnix repository root (`patch -p1`) with zero fuzz. Before patching, regenerate the `net80211` generated source with `net80211/gen-illumos-src.sh`.

Patch SHA-256: `9d469589bc5397efa89199a5c2fa86654a62956ab6ff4e0c33807e52b8e91f80`.

## Tests

`tests/scan-regression.py` contains 25 deterministic protocol/state/property tests and 10 negative controls. No random sleeps or timing-dependent interleavings are used. The existing mblk and DMA regression suites must also remain green.

## Physical acceptance

After a native build against `illumos-c893fd03ad`, install the resulting module and run `tests/run-ax101-scan-validation.sh` once as root. It runs DTrace concurrently with one `dladm scan-wifi`, and captures numeric RX opcode/group/qid/index, scan-completion events, init-task reason codes, RFKill state, beacon/probe-response counts, BSS-tree counts and ESS snapshot counts.

Physical scan acceptance requires non-placeholder ESSID entries in `dladm show-wifi` and corresponding beacon/probe/BSS evidence. Association, WPA2, DHCP, DNS and Internet remain separate tests.

## Immutable identity

Intel AX101 8086:54F0, subsystem 8086:0244, `iwx_cfg_so_a0_hr_b0`, firmware API 77 and firmware filename `iwx-so-a0-hr-b0-77`. Do not alter the pinned Solnix or illumos-gate commits.
